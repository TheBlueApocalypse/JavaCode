	/*
	Title: Lab 3 Buses

	Summary: This class serves to implement the Vehicle interface and create a bus as a subsection of 
	vehicle that also has a set number of seats and may or may not be double decker.
	
	Authors: Campbell Headrick, Cameron Carpenter

	Date Created: 2/7/2020

	Last Updated: 2/11/2020
	*/
public class Buses2 implements Vehicle2{
	private double price; 
	private int speed; 
	private String tagLine;
	private int seats;
	private boolean isDoubleDecker;
	//The variables used in this class are declared.
	public Buses2() {
		//First constructor sets a "default" value to every variable in the program.
		price=0;
		speed=0;
		tagLine="Default tagline";
		seats=0;
		isDoubleDecker=false;
	}
	public Buses2(double p, int sp, String t, int se, boolean i) {
		//Second constructor allows the user to manually input values for each variable.
		price=p/2;
		speed=sp/2;
		tagLine=t;
		seats=0;
		isDoubleDecker=i;
	}
	public double getPrice(){
			return price;
	}
	public int getSpeed(){
		return speed;
	}
	public String getTagLine(){
		return tagLine;
	}
	//"Get" methods return the values of the variables used by the interface methods to other classes.
	public void setPrice(double newPrice){
		price = newPrice/2;
	}
	//The price is = to the input from the driver divided by 2.
	public void setSpeed(int newSpeed){
		speed = newSpeed/2;
	}
	//The speed is equal to the input from the driver divided by 2.
	public void setTagLine(String newTagline){
		tagLine = newTagline;
	}
	//"Set" methods take in values from the driver for the interface methods and store them in this class.
	public int getSeats() {
		return seats;
	}
	public boolean getisDoubleDecker() {
		return isDoubleDecker;
	}
	//"Get" methods return the values of each exclusive variable to the driver.
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public void setDoubleDecker(boolean isDoubleDecker) {
		this.isDoubleDecker = isDoubleDecker;
	}
	//"Set" methods take in values exclusive to this class from the driver and store them in this class.
	public String toString() { 
	//This method returns the values of each variable to other classes in a form that can be easily printed.
		return "Bus [Price: " + price + "$, Speed: " + speed + " mph, Tagline: " + tagLine +", Number of seats: " + seats + ", Is double decker: "+isDoubleDecker+"] "; 
	} 
	public void betweenStops (int b) {
		//This class's unique method tells the user how much time there is between each bus stop.
		System.out.println("This bus takes approximately "+b+" minutes between each stop.");
	}
}
