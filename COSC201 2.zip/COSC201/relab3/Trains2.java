	/*
	Title: Lab 3 Trains

	Summary: This class serves to implement the Vehicle interface and create a train as a subsection of 
	vehicle that also has brand and year of model.
	
	Authors: Campbell Headrick, Cameron Carpenter

	Date Created: 2/7/2020

	Last Updated: 2/11/2020
	*/
public class Trains2 implements Vehicle2{
	private double price; 
	private int speed; 
	private String tagLine;
	private String type;
	private String destination;
	//The variables used in this class are declared.
	public Trains2() {
		//First constructor sets a "default" value to every variable in the program.
		price=0;
		speed=0;
		tagLine="Default tagline";
		type="Coal-powered";
		destination="Nowhere";
	}
	public Trains2(double p, int sp, String t,  String ty, String d) {
		//Second constructor allows the user to manually input values for each variable.
		price=p*2;
		speed=sp*2;
		tagLine=t;
		type=ty;
		destination=d;
	}
	public double getPrice(){
		return price;
	}
	public int getSpeed(){
		return speed;
	}
	public String getTagLine(){
		return tagLine;
	}
	//"Get" methods return the values of the variables used by the interface methods to other classes.
	public void setPrice(double newPrice){
		price = newPrice*2;
	}
	//The price is equal to the input from the driver times 2.
	public void setSpeed(int newSpeed){
		speed = newSpeed*2;
	}
	//The speed is equal to the input from the driver times 2.
	public void setTagLine(String newTagline){
		tagLine = newTagline;
	}
	//"Set" methods take in values from the driver for the interface methods and store them in this class.
	public String getType() {
		return type;
	}
	public String getDestination() {
		return destination;
	}
	//"Get" methods return the values of each exclusive variable to the driver.
	public void setType(String type) {
		this.type = type;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	//"Set" methods take in values exclusive to this class from the driver and store them in this class.
	public String toString() { 
		//This method returns the values of each variable to other classes in a form that can be easily printed.
			return "Train [Price: " + price + "$, Speed: " + speed + " mph, Tagline: " + tagLine +", Type of train: " + type + ", Destination: "+destination+"] ";
	}
	public void isRunning(boolean inOperation) {
		//This class's unique method tells the user whether or not the train is running today.
		if(inOperation==true) {
			System.out.println("This train is in operation today.");
		}
		else {
			System.out.println("This train is not in operation today.");
		}
	}
}
