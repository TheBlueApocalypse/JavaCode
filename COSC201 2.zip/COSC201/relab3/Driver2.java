import java.io.*;
import java.util.*;
	/*
	Title: Lab 3 Driver

	Summary: This class holds the main method that is used to create objects using the other classes
	for this lab and display examples of such objects to the user. Even with the same inputs for some
	variables, the result printed will be different because of the implementation of the interface
	allowing methods with the same name to do different things.
	
	Authors: Campbell Headrick, Cameron Carpenter

	Date Created: 2/7/2020

	Last Updated: 2/11/2020
	*/
public class Driver2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				Scanner input = new Scanner(System.in);
				Buses2 b1=new Buses2();
				//A new bus object called b1 is created.
				b1.setPrice(5);
				b1.setSpeed(50);
				b1.setTagLine("Example tagline 1");
				b1.setSeats(40);
				b1.setDoubleDecker(false);
				//All the values needed for v1 are set.
				System.out.println(b1.toString());
				//All the values in the b1 object are printed.
				b1.betweenStops(15);
				//The betweenStops method of the b1 object is run.
				//A second vehicle called "v2" is created as an example of using the Cars class.
				Cars2 c1=new Cars2();
				//A new car object called c1 is created.
				c1.setPrice(5);
				c1.setSpeed(50);
				c1.setTagLine("Example tagline 2");
				c1.setBrand("Toyota");
				c1.setYear(2006);
				//All the values needed for c1 are set.
				System.out.println(c1.toString());
				//All the values in the c1 object are printed.
				c1.maxSpeed(90);
				//The maxSpeed method of the c1 object is run.
				Trains2 t1= new Trains2();
				//A new train object called t1 is created.
				t1.setPrice(5);
				t1.setSpeed(50);
				t1.setTagLine("Example tagline 3");
				t1.setType("Electric");
				t1.setDestination("Washington DC");
				//All the values needed for t1 are set.
				System.out.println(t1.toString());
				//All the values in the t1 object are printed.
				t1.isRunning(true);
				String word = "";
				String timeConst = "";
				int dis = 0;
				double price = 0;
				
				System.out.println("What is the distance you will travel");	
				dis = input.nextInt();		
				System.out.println("What is your max price");	
				price = input.nextDouble();
				System.out.println(" what is your time cocnstraint? do you want fast travel or light on wallet?");
				timeConst = input.next();
				
				// comapartaors
				//The isRunning method of the t1 object is run.

	}
	// public <T> void UnderMaxPrice() {
		//for (T o : a) {
			//take accepted values from list and creates new list to add values to
			
			
			
			
			
		//}
	//}
	//static <> void Fastest() {
		//for () {
			// // compares each values spped to each one
			// stores the location of the item  then returns the item at the end
			//
		//}
	//}
	//static <> void Cheapest() {
		//for () {
			// // Correct
		//}
	//}
	

}
