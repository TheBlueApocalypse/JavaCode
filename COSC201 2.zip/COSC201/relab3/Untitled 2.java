

class Administrator  extends Employee{
	private String department;
	
	public Administrator (String ssn, int newSlaery, int hoursWorked, String depart){
		Employee(ssn, newSlaery, hoursWorked);
		department = depart;
	}
	//getters
}