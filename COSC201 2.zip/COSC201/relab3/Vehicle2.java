	/*
	Title: Lab 3 Interface

	Summary: This class serves as an interface for vehicles and can provide a price, speed, 
	and tagline for each instance.
	
	Authors: Campbell Headrick, Cameron Carpenter

	Date Created: 2/7/2020

	Last Updated: 2/11/2020
	*/
public interface Vehicle2 {
	;
	//The variables to be used by this interface are declared.
	public double getPrice();
	
	public int getSpeed();
	
	public String getTagLine();
	
	//"Get" methods return the values of each variable to other classes.
	public void setPrice(double newPrice);
	
	public void setSpeed(int newSpeed);
	
	public void setTagLine(String newTagline);
	
	//"Set" methods take in values from the driver and store them in this class.
	public String toString();
	//toString method is used to print out all the values used in each other class in a presentable fashion.
}
