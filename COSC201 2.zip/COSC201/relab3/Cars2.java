	/*
	Title: Lab 3 Cars

	Summary: This class serves to implement the Vehicle interface and create a car as a subsection of 
	vehicle that also has a brand and year of model.
	
	Authors: Campbell Headrick, Cameron Carpenter

	Date Created: 2/7/2020

	Last Updated: 2/11/2020
	*/
public class Cars2 implements Vehicle2{
	private double price; 
	private int plugIn; 
	private String model;
	private String make;
	private int year;
	//The variables used in this class are declared.
	public Cars2() {
		//First constructor sets a "default" value to every variable in the program.
		price=0;
		speed=0;
		tagLine="Default tagline";
		brand="Unknown";
		year=0;
	}
	public Cars2(double p, int sp, String t,  String b, int y) {
		//Second constructor allows the user to manually input values for each variable.
		price=p;
		speed=sp;
		tagLine=t;
		brand=b;
		year=y;
	}
public double getPrice(){
	return price;
}
public int getSpeed(){
	return speed;
}
public String getTagLine(){
	return tagLine;
}
//"Get" methods return the values of the variables used by the interface methods to other classes.
public void setPrice(double newPrice){
	price = newPrice;
}
//The price is equal to the input from the driver.
public void setSpeed(int newSpeed){
	speed = newSpeed;
}
//The speed is equal to the input from the driver.
public void setTagLine(String newTagline){
	tagLine = newTagline;
}
//"Set" methods take in values from the driver for the interface methods and store them in this class.
public String getBrand() {
	return brand;
}
public int getYear() {
	return year;
}
//"Get" methods return the values of each exclusive variable to the driver.
public void setBrand(String brand) {
	this.brand = brand;
}
public void setYear(int year) {
	this.year = year;
}
//"Set" methods take in values exclusive to this class from the driver and store them in this class.
public String toString() { 
//This method returns the values of each variable to other classes in a form that can be easily printed.
	return "Car [Price: " + price + "$, Speed: " + speed + " mph, Tagline: " + tagLine +", Brand: " + brand + ", Year of model: "+year+"] ";
}
public void maxSpeed (int m) {
	//This class's unique method tells the user the max speed of the car.
	System.out.println("The max speed of this car is "+m+" mph.");
}
} 
