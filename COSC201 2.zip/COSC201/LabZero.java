import java.util.Scanner;
class LabZero {
	public static void main(String[] args) {
		int n;	
		Scanner input = new Scanner(System.in);
		// Menu output
		System.out.println("System Menu:");
		System.out.println("Option 1: enter '1' Function: Prints values 0 to X"); 
		System.out.println("Option 2: enter '2' Function: Reads and prints text file"); 
		System.out.println("Option 3: enter '3' Function: Finds Mean, Min, Max"); 
		System.out.println("Option 4: enter '4' Function: Exits Program "); 
		System.out.println("Input an integer"); 
			
		while ((n = input.nextInt()) != 4) {
			System.out.println("You entered " + n);
			if (n == 1)
		//fib function
			{
				int x;
				int counter;
				System.out.println("Input an integer"); 
				x = input.nextInt();
				counter = x *-1;
				fib(x, counter);
			}
			else if(n == 2){
			
			}
			else if(n == 3){
				System.out.println("How many nubers do you want to put into a list");
				double max = 0;
				double min = 0;
				double sum = 0;
				double count = 0;
				double length = input.nextInt();
				double[] statsList = new double[5];
				System.out.println("Input an integer");
				double curr = input.nextDouble();
				max = curr;
				min = curr;
				sum = curr;
				count++;
				statsList[0]= max;
				statsList[1]= min;
				statsList[2]= sum;
				statsList[3]= count;
				statsList[4]= length;
				arrayStats(statsList);
			}
		}

	}
	static int fib(int x, int counter)	
	{  
		if(x == 1)	
		{
		// base case
			System.out.println(counter+1);
			System.out.println(counter+2);
			return 1;
		// return print statments
		}
		else
		{	
		
			System.out.println(x+counter);
			counter+=2;
			return fib(x-1, counter);
		// return print statments
		
		}
	}
	static double arrayStats(double statsList[])
	{ 	
		Scanner input = new Scanner(System.in);
		double curr = 0;
		if(statsList[3] == statsList[4])
		{
			// calculations for the final values
			double mean = 0;
			mean = statsList[2]/statsList[3];
			System.out.println("The Mean is: " + mean);
			System.out.println("The Max is: " + statsList[0]);
			System.out.println("The Min is: " + statsList[1]);
			// base recursive case
			return 1;
		}
		else
		{ 
			System.out.println("Input an integer"); 
			curr = input.nextInt();
			statsList[3]++;
			statsList[2]= statsList[2] + curr;
			// max evaluator
			if(curr > statsList[0])
			{
				statsList[0] = curr;
			}
			// max evaluator
			if(curr<statsList[1])
			{
				statsList[1] = curr;
			}
			// recursive case
			return arrayStats(statsList);
		}		 	
	}
}	
