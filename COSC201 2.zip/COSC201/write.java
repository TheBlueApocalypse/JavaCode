package readfile;
import java.io.*;
import java.util.Scanner;
class Untitled {
	public static void main(String[] args) {
		//File file = new File("Wordtext");
		java.util.Scanner sc = new java.util.Scanner(System.in);
		//readFile(scan);
	}
	/*static String readFile(Scanner theFile)
	{	
		String[] wordList = new String[1];
		String word = "";
		if(theFile.hasNext())
		{
			word = theFile.next();
		}
		wordList[1] = word;
		System.out.println(wordList[1]);
		return readFile(theFile) ;
	}*/
}