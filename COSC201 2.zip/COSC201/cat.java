class cat extends pet {
	private
}