package LinkedList;

/*
Ariel Webster
Created: 9/18/18
For in class example and class lab, class 201

Fill in the methods below to create a functioning singly linked list
You should not change the provided method signatures, unless directed to by myself or the TA
*/

public class LinkedListStart {
	
	public Node head = null;

	public static void main(String [] args){
		
		//nodes to be added to the linkedlist
		Node p1 = new Node("Hugh");
		Node p2 = new Node("Taylor");
		Node p3 = new Node("Caleb");
		Node p4 = new Node("Justin");
		Node p5 = new Node("Drew");
		Node p6 = new Node("Christine");
		Node p7 = new Node("Will");
		Node p8 = new Node("Maggie");
		Node p9 = new Node("Rose");
		Node p10 = new Node("Hannah");
		Node p11 = new Node("Tamara");
		Node p12 = new Node("Jackie");
		Node p13 = new Node("Annette");
		
		LinkedListStart ll = new LinkedListStart();
		ll.addFirst(p7);
		ll.addFirst(p8);
		ll.PrintList();
		
		
		
	}
	
	//adds an element to the head of the linked list
	public void addFirst(Node p){
		if (head == null){
			head = p;
		}else{
			p.setNext(head);
			head = p;
		}
	}
	
	//adds an element to the tail of the linked list
	public void addLast(Node p){
		Node x = new Node();
		x = head
		if(head = null){
			head = p
		}
		else{
			while(x != null){
				system.out.println();
				x = x.getNext();
			}
			index.setNext(p);
		}
	}
	
	//adds an element to a specific index within the linked list
	public void add(Node p, int i){
	
	}
	
	//removes the element at the head of the linked list
	public void removeFirst(){
		if (head != null) {
			head = head.getNext();
		}
	}
	
	//removes the element at the tail of the linked list
	public void removeLast(){
		
	}
	
	//removes an element at a specific index within the linked list
	public void remove(Node p){
		
	}
	
	//removes every element from the linked list
	public void clear(){
		
	}
	
	//returns true if the linked list contains specified Node, returns false if not
	public boolean contains(Node p){
		return false;
	}
	
	//returns the node at specified index.
	public Node get(int i){
		return null;
	}
	
	//returns the index of the specified node
	public int indexOf(Node p){
		return 0;
	}
	
	//prints out the Linked List
	public void PrintList(){
		Node index = head;
		while (index != null){
			System.out.println(index.getName());
			index = index.getNext();
		}
	}
	
}