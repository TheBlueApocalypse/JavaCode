import java.util.Scanner;
class Untitled {
	public static void main(String[] args) {
		int n;
				
		Scanner input = new Scanner(System.in);
		System.out.println("Input an integer"); 
				
		while ((n = input.nextInt()) != 4) {
			System.out.println("You entered " + n);
			//part1
			if (n == 1)
			{
				int x;
				System.out.println("Input an integer"); 
				Fib(input.nextInt());
			}
			else if(n == 2)
			else if(n == 3){
				double w;	 
				double x = 0;
				double y = 0;
				double z = 0;
				double counter;
				System.out.println("Input an integer");
				w = input.nextDouble();
				arrayStats(w,x,y,z, counter);
			}
			System.out.println("Input an integer");
			
		}
	}
	static int Fib(int x)	
	{  
		if(x == 1)	
		{
		// base case
			System.out.println("1");
			return 1;
			// return print statments
		}
		else
		{	
			System.out.println(x);
			return Fib(x-1);
			// return print statments
			
		}
	}

	/*static String recursiveCall2(Scanner fileName){
		String words = "";

		if(theFile.hasNext())
		{
			 String word = theFile.next();
			 getWordsString(theFile);
		}
		return words + getWordsString(theFile);
	}*/


	/*static void arrayStats(double w, double max, double min, double mean , double counter);
	{ 	
		if (w == 0)
		{	
			z = z/counter;
			System.out.println("The Mean is: " + mean);
			System.out.println("The Max is: " + max);
			System.out.println("The Min is: " + min);
			return 1;
		}
		else
		{ 
			counter++;
			z = z + w;
			if(w > x){
				x = w;
			}
			else if(w<y)
			{
				y = w;
			}
			System.out.println("Input an integer"); 
			w = input.nextDouble();
			return arrayStats(w,max,min,mean,counter);
		} 
		
	}*/
}
//part1
