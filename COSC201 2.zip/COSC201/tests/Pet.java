class Pet {
	public String words;
	public Pet(){
		words  = "Your Pet:";
	}
	public void action(){
		System.out.println(words);
	}
}