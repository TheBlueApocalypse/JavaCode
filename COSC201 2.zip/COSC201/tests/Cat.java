class Cat extends Pet{
	public String word;
	public Cat(){
		word = "is a cat that plays with yarn";
	}
	public void action(){
		System.out.println(word);
	}
}