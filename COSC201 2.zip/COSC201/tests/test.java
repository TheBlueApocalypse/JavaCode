class test {
	public static void main(String[] args) {
		Cat c1 = new Cat();
		c1.action();
	}
}