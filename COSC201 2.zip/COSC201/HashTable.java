

/* HashTable.java
   CSC 225 - Spring 2016
   Template for string hashing
   
   =================
   
   Modify the code below to use linear rehashing and quadratic rehashing to resolve collisions.
   
   Your task is implement the insert, find, remove, and resize methods for the hash table.
  
   The load factor, how full the table is, should always remain in the range [0.25,0.75].
   
  
    =================
   
   This template includes some testing code to help verify the implementation.
   To interactively provide test inputs, run the program with
	java HashTable
	
   Input data should consist of a list of strings to insert into the hash table, one per line,
   followed by the token "###" on a line by itself, followed by a list of strings to search for,
   one per line.
	
   To conveniently test the algorithm with a large input, create
   a text file containing the input data and run the program with
	java HashTable file.txt
   where file.txt is replaced by the name of the text file.

   B. Bird - 07/04/2015
   M. Simpson - 21/02/2016    A. Webster 13/10/2018
*/

import java.util.*;
import java.io.*;
import java.lang.Math;

public class HashTable{

    boolean linearRehashing;
	DataStructure hashTable = new DataStructure(10);
	//The size of the hash table.
	int TableSize;
     
	//The current number of elements in the hash table.
	int count;
	
	// DECLARE AND INITIALZE YOUR TABLE DATA STRUCTURE HERE
	// Your data structure should be an object with:
	// String [] T -- representing the array used for the table
	// long collisioncount
	// long lastPlaceChecked
	private class DataStructure{
		public String[] T;
		public long collisioncount;
		public long lastPlaceChecked;
		public int maxcollisioncount;
		
		public DataStructure(int startSize) {
			T = new String[startSize];
			TableSize = startSize;
		}	
		
		public String get(int index) {
			if(index >= T.length) {
				return null;
			} else {
				return T[index];
			}
		}
		
		public void place(int index,String val) {
			if(index >= T.length) {
				resize(index+1);
				insert(val);
			}
			else {
				T[index] = val;
			}
		}
		
		
		public void resize(int newSize) {
			String[] oldData = T.clone();
			T = new String[newSize];
			TableSize = newSize;
			for(int i = 0;i < oldData.length;i++) {
				if(oldData[i] != null) {
					count--; //Prevent the insertion of old data from changing the count
					insert(oldData[i]);
				}
			}
		}
		public void del(int index) {
			T[index] = null;
		}
		
		public int getSize() {
			return T.length;
		}
	}
	
	/* hash(s) = ((2^0)*s[0] + (2^1)*s[1] + (2^2)*s[2] + ... + (2^(k-1))*s[k-1]) mod TableSize
	   
	(where s is a string, k is the length of s and s[i] is the i^th character of s)
	   Return the hash code for the provided string.
	   The returned value is in the range [0,TableSize-1].
	*/
	public int hash(String s){
		int h = 0;
		for (int i=0; i<s.length(); i++) {
			h += s.charAt(i) * Math.pow(2,i);
		}
		return h % TableSize;
	}
	
	public int linearRehash(String val,int oldKey) {
		oldKey++;
		hashTable.lastPlaceChecked = oldKey;		
		hashTable.collisioncount++;

		return oldKey;
	}
	
	
	public int quadraticRehash(String val,int oldKey,int times) {
		oldKey += Math.pow(2, times);
		hashTable.collisioncount++;
		return oldKey;
	}
	
	/* insert(s)
	   Insert the value s into the hash table and return the index at 
	   which it was stored.
	*/
	public int insert(String s){
		int hashVal = hash(s);
		int cycleCount = 0;
		
		while(hashTable.get(hashVal) != null) {
			if(linearRehashing) {
				hashVal = linearRehash(s,hashVal);
			} else {
				hashVal = quadraticRehash(s,hashVal,cycleCount);
			}
			cycleCount++;
		}
		
		if(cycleCount > hashTable.maxcollisioncount) {
			hashTable.maxcollisioncount = cycleCount;
		}
		
		count++;
		hashTable.place(hashVal,s);
		resize();
		return hashVal;
	}
	
	/* find(s)
	   Search for the string s in the hash table. If s is found, return
	   the index at which it was found. If s is not found, return -1.
	*/
	public int find(String s){
		int hashVal = hash(s);
		int cycleCount = 0;
		int placeIndex = -1;
		
		while(hashTable.get(hashVal) != null) {
			
			hashTable.lastPlaceChecked = hashVal;
			
			if(hashTable.get(hashVal).equals(s)) {
				placeIndex = hashVal;
				break;
			}
			
			if(linearRehashing) {
				hashVal = linearRehash(s,hashVal);
			} else {
				hashVal = quadraticRehash(s,hashVal,cycleCount);
			}
			
			cycleCount++;
		}
		
		if(cycleCount > hashTable.maxcollisioncount) {
			hashTable.maxcollisioncount = cycleCount;
		}
		
		return placeIndex;
	}
	
	
	
	/* remove(s)
	   Remove the value s from the hash table if it is present. If s was removed, 
	   
	   return the index at which it was removed from. If s was not removed, return -1.
	*/
	public int remove(String s){
		int i  = find(s);
		if(i == -1){
			return -1;
		}
		else{
			hashTable.del(i);
			count--;
			resize();
			return i;
		}
	}
	
	
	
	/* resize()
	   Resize the hash table to be within the load factor requirements.
	*/
	public void resize(){
		double usage = (double)count/(double)TableSize;
		if(usage > 0.75 || usage < 0.25) {
			int desiredSize = count * 2;
			hashTable.resize(desiredSize);

		}
	}
	
	public void resetCollisionCounters() {
		hashTable.collisioncount = 0;
		hashTable.maxcollisioncount = 0;
	}
	
	
	public void printHash() {
		for(int i = 0;i < hashTable.T.length;i++) {
			System.out.print(hashTable.T[i] + ((i == hashTable.getSize() - 1) ? "\n" : ","));
		}
	}
	
	
	/* main()
	   Contains code to test the hash table methods. 
	*/
	public static void main(String[] args){
		Scanner s = new Scanner(System.in);
		boolean interactiveMode = false;
		boolean linearhashing = false;//user variable that helps determin the rehashing method for the hash table
		System.out.println("Would you like to use quadratic(q) or linear(l) rehashing?");
		String input = s.next();
		//errorocode for the rehasshing type
		while(!input.contentEquals("q") && !input.equals("l")) {
			System.out.println("Please enter q or l!");
		}
		//prep work for the rehash later
		if(input == "q") {
			//quadratic rehassing chosen
			linearhashing = false;
		} else {
			//linear rehassing chosen
			linearhashing = true;
		}
		
		//preprep error checks
		if (args.length > 0){
			try{
				// this is where a file can be plasced in for the hash table to try and read a massive file.
				s = new Scanner(new File(args[0]));
			} catch(java.io.FileNotFoundException e){
				//failure to read file error;
				System.out.printf("Unable to open %s\n",args[0]);
				return;
			}
			System.out.printf("Reading input values from %s.\n",args[0]);
		}else{
			//if interactiveMode is false this allows the file input for the hash table
			interactiveMode = true;
			s = new Scanner(System.in);
		}
		s.useDelimiter("\n");
		//checking for enter regex char's for the program string so no errors are thrown
		if (interactiveMode){
			System.out.printf("Enter a list of strings to store in the hash table, one per line.\n");
			System.out.printf("To end the list, enter '###'.\n");
			// ### quit case for the input string of the future hash table
		}else{
			System.out.printf("Reading table values from %s.\n",args[0]);
		}
		//user interface
		
		Vector<String> tableValues = new Vector<String>();
		Vector<String> searchValues = new Vector<String>();
		Vector<String> removeValues = new Vector<String>();
		
		String nextWord;
		//preps the user made strings for assignment
		while(s.hasNext() && !(nextWord = s.next().trim()).equals("###"))
			tableValues.add(nextWord);
		System.out.printf("Read %d strings.\n",tableValues.size());
		//reading the user input for seach based on user input.
		if (interactiveMode){
			System.out.printf("Enter a list of strings to search for in the hash table, one per line.\n");
			System.out.printf("To end the list, enter '###'.\n");
		}else{
			//prints ment for the file system
			System.out.printf("Reading search values from %s.\n",args[0]);
		}	
		//
		while(s.hasNext() && !(nextWord = s.next().trim()).equals("###"))
			searchValues.add(nextWord);
		System.out.printf("Read %d strings.\n",searchValues.size());
		//
		if (interactiveMode){
			//base printing for the second time this time to ask for has table remove values
			System.out.printf("Enter a list of strings to remove from the hash table, one per line.\n");
			System.out.printf("To end the list, enter '###'.\n");
		}else{
			//cheking the values for a file read
			System.out.printf("Reading remove values from %s.\n",args[0]);
		}
		//reading the new remove values for the hash table
		while(s.hasNext() && !(nextWord = s.next().trim()).equals("###"))
			removeValues.add(nextWord);
		System.out.printf("Read %d strings.\n",removeValues.size());
		
		HashTable H = new HashTable();
		H.linearRehashing = linearhashing;
		long startTime, endTime;
		double totalTimeSeconds;
		
		startTime = System.currentTimeMillis();
			//linear rehashing or quadratic rehasing for the list oforginal values
		for(int i = 0; i < tableValues.size(); i++){
			String tableElement = tableValues.get(i);
			long index = H.insert(tableElement);
		}
		endTime = System.currentTimeMillis();
		totalTimeSeconds = (endTime-startTime)/1000.0;
		//returning the run time for the system in seconds
		
		System.out.printf("Inserted %d elements.\n Total Time (seconds): %.2f\nTotal collisions: %d\nMaximum collisions:%d\n",tableValues.size(),totalTimeSeconds,
				H.hashTable.collisioncount,H.hashTable.maxcollisioncount);
				//counters kept to show how many collisions their were and max collisions	
		H.resetCollisionCounters();
		int foundCount = 0;
		int notFoundCount = 0;
		startTime = System.currentTimeMillis();
		//parsing through the values given to search for and see if they exist.
		for(int i = 0; i < searchValues.size(); i++){
			String searchElement = searchValues.get(i);
			long index = H.find(searchElement);
		////we will keep track of the counts of the of the time the values are and are not found.
			if (index == -1)
				notFoundCount++;
			else
				foundCount++;
		}
		//also calculating the time tables for the search function
		endTime = System.currentTimeMillis();
		totalTimeSeconds = (endTime-startTime)/1000.0;
		//printing function for the values that were calculated
		System.out.printf("Searched for %d items (%d found, %d not found).\n Total Time (seconds): %.2f\nTotal collisions: %d\nMaximum collisions:%d\n",
							searchValues.size(),foundCount,notFoundCount,totalTimeSeconds,H.hashTable.collisioncount,H.hashTable.maxcollisioncount);
							
		
		int removedCount = 0;
		int notRemovedCount = 0;
		
		startTime = System.currentTimeMillis();
		//resetting all values
		//preping the remove list function and the list of remove values
		for(int i = 0; i < removeValues.size(); i++){
			String removeElement = removeValues.get(i);
			long index = H.remove(removeElement);
			//counting the number of times a value is removed from the list
			if (index == -1)
				notRemovedCount++;
			else
				removedCount++;
		}
		//calculate end times
		endTime = System.currentTimeMillis();
		totalTimeSeconds = (endTime-startTime)/1000.0;
		//printout files.
		System.out.printf("Tried to remove %d items (%d removed, %d not removed).\n Total Time (seconds): %.2f\n",
							removeValues.size(),removedCount,notRemovedCount,totalTimeSeconds);
	}
}
	