class Hi {
	public static void main(String[] args) {
		ChoclateChip c1 = new ChoclateChip();
		ChoclateChip c2 = new ChoclateChip(10);
		int i = c2.compareTo(c1);
		System.out.println(i);
	}
}