public class IntList {
	private ConsCell starts; // first in the list or null

	/**
	 * Construct a new IntList given its first ConsCell
	 * @param s the first ConsCell in the list or null
	 */
	public IntList(ConsCell s) {
		starts = s;
	}
	public ConsCell getStart(){
		return starts;
	}
	public void setStart(ConsCell s){
		starts = s;
	}
	/**
	 * Cons the given element h onto us and return the
	 * resulting IntList.
	 * @param h the head int for the new list.
	 * @return the IntList with head h and us for a tail.
	 */
	public IntList cons(int h) {
		return new IntList(new ConsCell(h, starts));
	}

	/**
	 * Get our length.
	 * @return our int length
	 */
	public int length() {
		int len = 0;
		ConsCell cell = starts;
		while (cell != null) {
			len++;
			cell = cell.getTail();
		}
		return len;
	}

	/**
	 * Print ourself to System.out
	 */
	public void print() {
		System.out.print("[");
		ConsCell a = starts;
		while (a != null) {
			System.out.print(a.getHead());
			a = a.getTail();
			if (a != null) System.out.print(",");
		}
		System.out.println("]");
	}
	//exersise 2
	public boolean contains(int n) {
		ConsCell x = starts;
		while (x != null) {
			if (x.getHead() == n) 
				return true;
			else 
				x = x.getTail();
		}	
		return false;
	}
	//exersise 3
	public boolean equals(IntList y) {
		if(this.getStart().getHead() == y.getStart().getHead() && this.getStart().getTail() == y.getStart().getTail() && this.length() == y.length())
			return true;
		else
			return false;
	}
	//exersise 4
	public IntList append(IntList y) {
		ConsCell x = starts;
		while (x.getTail() != null) {
			x = x.getTail();
		}
		x.setTail(y.getStart());
		return this;
	}
	//exersise 5
	public IntList reverse() {
		IntList rev = new IntList(null);
		ConsCell x = starts;
		while (x != null) {
			rev.cons(x.getHead());
		x = x.getTail();
		}
		return rev;
	}
	//exersise 6
	public void reverseMe()
	{
		ConsCell prev = null;
		ConsCell current = starts;
		ConsCell next = null;
		while (current != null) {
			next = current.getTail();
			current.setTail(prev);
			prev = current;
			current = next;
		}
		this.setStart(prev);
	}
}

