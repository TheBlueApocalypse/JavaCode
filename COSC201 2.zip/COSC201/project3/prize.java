class prize {
	public static void main(String[] args) {
		Tree value = new Tree();
		value.setRoot(value.insert(value.getRoot(),2));
		System.out.println(value.getRoot().getNum());
		System.out.println(value.getRoot().getLeft());
		System.out.println(value.getRoot().getRight());
		value.setRoot(value.insert(value.getRoot(),1));
		System.out.println(value.getRoot().getNum());
		value.postOrder(value.getRoot());
		value.setRoot(value.insert(value.getRoot(),6));
		value.setRoot(value.insert(value.getRoot(),7));
		value.setRoot(value.insert(value.getRoot(),3));
		value.setRoot(value.insert(value.getRoot(),4));
		value.setRoot(value.insert(value.getRoot(),5));
		value.printer(value.getRoot(), "", false);
		System.out.println("Hi");
		value.postOrder(value.getRoot());
		//value.print();
		
	}
}