/***
 * Simple implementation of a binary search tree node
 * Written by William Capon and Cameron Carpenter for Lab 7
 * 4/7/2020
 */
//toString: a function that creates a string from the node
//input: N/a
//output: a string variable
public class Node {

	private int num; 
	private Node right; //Points to greater node
	private Node left; //Points to lesser node
	private int lCount;
	private int rCount;
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public Node() {
		this.num = num;
		right = null;
		left = null;
		lCount = 0;
		rCount = 0;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public Node(int num) {
		this.num = num;
		right = null;
		left = null;
		lCount = 0;
		rCount = 0;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public int getNum() {
		return num;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public void setName(int num) {
		this.num = num;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public Node getRight() {
		return right;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public Node getLeft() {
		return left;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public void setRight(Node right) {
		this.right = right;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public void setLeft(Node left) {
		this.left = left;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable

	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public String toString(){
		return Integer.toString(num);
	}
	//incDownRight: a function that incriments the left counter up used for determining balance
	//input: N/a
	//output: N/a
	public void incUpLeft(){
		lCount++;
	}
	//incDownRight: a function that incriments the Left counter down used for determining balance
	//input: N/a
	//output: N/a
	public void incDownLeft(){
		lCount--;
	}
	//incDownRight: a function that incriments the right counter up used for determining balance
	//input: N/a
	//output: N/a
	public void incUpRight(){
		rCount++;
	}
	//incDownRight: a function that incriments the right counter down used for determining balance
	//input: N/a
	//output: N/a
	public void incDownRight(){
		rCount--;
	}
	public int getLCount(){
		return lCount;
	}
	public int getRCount(){
		return rCount;
	}
	
}