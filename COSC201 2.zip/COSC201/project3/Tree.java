
class Tree {
	private Node tree;
	public Tree(){
		tree = null;
	
	}		
	public int bigger(int a, int b) {
		if(a > b){
			return a;
		}
		else{
			return b;
		}
	}
	public Node getRoot(){
		return tree;
	}
	public void setRoot(Node node){
		this.tree = node;
	}
	public Node rightRotate(Node y) {
		Node x = y.getLeft();
		Node temp = x.getRight();

		x.setRight(y);
		y.setLeft(temp);
		
		int tempNum = x.getRight().getHeight()+1;
		x.getRight().setHeight(tempNum);
		tempNum = y.getRight().getHeight()+1;
		y.getRight().setHeight(tempNum);
		
		y.setHeight(bigger(y.getLeft().getHeight(), y.getRight().getHeight()));
		x.setHeight(bigger(x.getLeft().getHeight(), x.getRight().getHeight()));

		return x;
	}
	//left rotate(node x) this will rotate the values in one of 4 ways
	//
	//
	public Node leftRotate(Node x) {
		Node y = x.getRight();
		Node temp = y.getLeft();

		y.setLeft(x);
		x.setRight(temp);
		
		int tempNum = bigger(x.getLeft().getHeight(), x.getRight().getHeight()) +1;
		x.setHeight(tempNum);
		tempNum = bigger(y.getLeft().getHeight(), y.getRight().getHeight())+1;
		y.setHeight(tempNum);

		return y;
	}
	public int calcBalanceValue(Node current) {
		if (current == null)
			return 0;
		return current.getLeft().getHeight() - current.getLeft().getHeight();
	}
	public Node insert(Node node, int num) {
		if (node == null){
			Node newN = new Node(num);
			return newN;
		}			
		if (num < node.getNum()){
			node.setLeft(insert(node.getLeft(), num));
		}
		else if (num > node.getNum()){
			node.setRight(insert(node.getRight(), num));
		}
		else{
			return node;
		}
		int tempNum = 0;
		if(){
			tempNum = 1;
		}
		else if(node.getLeft() == null){
			tempNum = 1 + bigger(0, node.getRight().getHeight());
		}
		else if(node.getRight() == null){
			tempNum = 1 + bigger(node.getRight().getHeight(), 0);
		}
		else{
			tempNum = 1 + bigger(node.getLeft().getHeight(), node.getRight().getHeight());
		}
		node.setHeight(tempNum);

		int balance = calcBalanceValue(node);

		if (balance > 1) {
			if (num < node.getLeft().getNum()) {
				return rightRotate(node);
			} else if (num > node.getLeft().getNum()) {
				node.setLeft(leftRotate(node.getLeft()));
				return rightRotate(node);
			}
		}
		if (balance < -1) {
			if (num > node.getRight().getNum()) {
				return leftRotate(node);
			} else if (num < node.getRight().getNum()) {
				node.setLeft(rightRotate(node.getLeft()));
				return leftRotate(node);
			}
		}
		return node;
	}

	public Node nodeWithMimumValue(Node node) {
		Node current = node;

		while (current.getLeft() != null)
			current = current.getLeft();

		return current;
	}

	public Node delete(Node tree, int num) {
		if (tree == null)
			return tree;

		if (num < tree.getNum())
			tree.setLeft(delete(tree.getLeft(), num));

		else if (num > tree.getNum())
			tree.setRight(delete(tree.getRight(), num));

		else {
			if ((tree.getLeft() == null) || (tree.getRight() == null)) {
				Node temp = null;
				if (temp == tree.getLeft())
					temp = tree.getRight();
				else
					temp = tree.getLeft();

				if (temp == null) {
					temp = tree;
					tree = null;
				} else
					tree = temp;
			} else {
				Node temp = nodeWithMimumValue(tree.getRight());
				tree.setNum(temp.getNum());
				tree.setRight(delete(tree.getRight(), temp.getNum()));
			}
		}

		if (tree == null)
			return tree;
		int tempNum = bigger(tree.getLeft().getHeight(), tree.getRight().getHeight()) + 1;
		tree.setHeight(tempNum) ;
		int balance = calcBalanceValue(tree);
		if (balance > 1) {
			if (calcBalanceValue(tree.getLeft()) >= 0) {
				return rightRotate(tree);
			} else {
				tree.setLeft(leftRotate(tree.getLeft()));
				return rightRotate(tree);
			}
		}

		if (balance < -1) {
			if (calcBalanceValue(tree.getRight()) <= 0) {
				return leftRotate(tree);
			} else {
				tree.setRight(rightRotate(tree.getRight()));
				return leftRotate(tree);
			}
		}
		return tree;
	}		
	public void lookUp(int num, Node root){
		if(num == root.getNum()){
			System.out.println("we found the value " + num + ". Thank you come again");
			return;
		}
		else if(num < root.getNum()){
			lookUp(num, root.getLeft());
		}
		else{
			lookUp(num, root.getLeft());
		}
	}	

	public void preOrder(Node current){
		if(current != null){ 
			System.out.print(current.getNum() + " "); 
			preOrder(current.getLeft()); 
			preOrder(current.getRight()); 
		} 
	}
	public void inOrder(Node current) {
		if(current != null) {
			inOrder(current.getLeft());
			System.out.print(current.getNum() + " ");
			inOrder(current.getRight());
		}
	}
	public void printer(Node current,String spacing, boolean indentEnd) {
		if(current != null) {
			//System.out.println(spacing);
			if(indentEnd == true){
				System.out.println(spacing + "Right: " + current.getNum());		
				spacing+= "  ";
			}
			else if(current == tree && indentEnd == false){
				System.out.println(spacing + "trees: " + current.getNum());		
				spacing+= "| ";
			}
			else{
				System.out.println(spacing + "Left: " + current.getNum());		
				spacing+= "| ";
			}
			printer(current.getLeft(), spacing, false);
			printer(current.getRight(), spacing, true);
		}
	}
	public void postOrder(Node current) {
		if(current != null) {
			postOrder(current.getLeft());
			postOrder(current.getRight());
			System.out.print(current.getNum() + " ");
			
		}
	}
	//public void print(){
		//ArrayList<Integer> treeList = new ArrayList<Integer>();
	//}
}