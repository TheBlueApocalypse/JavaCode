public class Node {
	private int num;
	private int height;
	private Node left;
	private Node right;
	public Node(int d) {
		num = d;
		height = 1;
		left = null;
		right = null;
	}
	public Node getRight() {
		return right;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public Node getLeft() {
		return left;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public void setRight(Node right) {
		this.right = right;
	}
	//toString: a function that creates a string from the node
	//input: N/a
	//output: a string variable
	public void setLeft(Node left) {
		this.left = left;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int value) {
		this.height = value;
	}
	public int getNum() {
		return this.num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
}