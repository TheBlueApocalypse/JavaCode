import java.util.Arrays;

public class Lab2 {
	/*
	Title: Lab 2
	BIG O FOR THIS IS (N^2) no mater how you look at the program

	Summary: The class sorts an array two different ways. The first does so by flipping subsections of the array,
	while the second uses recursion.
	
	Author: Campbell Headrick

	Date Created: 1/31/2020

	Last Updated: 2/1/2020
	*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab2 myLab = new Lab2();
		//A new instance of this class is created called "myLab".
		int[] array = {5, 3, 10, 4, 1, 8, 2, 9, 6, 7};
		//An array is created to be sorted by the methods. Any array of any size and combination of ints will work.
		int aLength=array.length;
		//An int called "aLength" is created to store the length of the array.
		myLab.print(array, 0, aLength);
		//The array is printed in its current state before it has been sorted.
		System.out.println("");
		long startTime = System.currentTimeMillis();
		//A long called "startTime" is created to track the starting time when methods are run.
		array=myLab.selectSort(array, 0, 0, 99999, aLength, 0);
		//The array is set to the result of the selectSort method, which will sort it recursively using selection sort. This instance is the worst case scenario in terms of time complexity.
		myLab.print(array, 0, aLength);
		//The array is printed after having been sorted.
		long endTime = System.currentTimeMillis();
		//A long called "endTime" is created to track the time after methods are run.
		double totalTimeSeconds = (endTime-startTime);
		//A double called "totalTimeSeconds" is created to hold the difference between the start and endtime of running a method, it is set to such.
		System.out.printf("Total Time (Miliseconds): %.4f\n",totalTimeSeconds);
		//The user is informed of how long the sort took to perform. It should take O(n*n) time.
		startTime = System.currentTimeMillis();
		//startTime is set to the current time.
		array=myLab.selectSort(array, 0, 0, 99999, aLength, 0);
		//The array is set to the result of the selectSort method, which will sort it recursively using selection sort. This instance is the best case scenario in terms of time complexity (the numbers are already in order).
		endTime = System.currentTimeMillis();
		//endTime is set to the current time.
		totalTimeSeconds = (endTime-startTime);
		//totalTimeSeconds is set to the difference between endTime and startTime.
		System.out.printf("Total Time (Miliseconds): %.4f\n",totalTimeSeconds);
		//The user is informed of how long the sort took to perform. It should take O(n) time.

	}
	public int[] selectSort(int[] a, int val1, int val2, int min, int length, int runs) {
		//This method uses Selection Sort to sort an array. The parameters are as follows:
		//a: the array that is sorted throughout the method.
		//val1: the "current" place in the array.
		//val2: the place of the smallest remaining number in the array.
		//min: the smallest remaining number in the array.
		//length: the length of the array.
		//runs: how many times the method has gone through every value in the array. This is used to make the method disregard every number that it has already placed in its proper location.
		boolean rightOrder=true;
		//A boolean called "rightOrder" is created and set to true. This is used to check if the array is in the right order. It is set to true by default.
		if(val1>=length) {
			//If statement checks if val1 has reached length, and therefore if the method has searched the entire array. If it has, it checks if the array is successfully sorted yet.
			rightOrder=checkArray(a, 0, length, rightOrder);
			if(rightOrder==true) {
				//If the array has been successfully sorted, it is returned to the main method.
				return a;
			}
			else {
				//Otherwise, the following operations are performed:
				if(val2!=runs) {
					//If val2 isn't equal to runs (and therefore isn't in its proper place) then the following operations are performed:
					a[val2]=a[runs];
					//The value at place val2 in the array is set equal to the value at place runs.
					a[runs]=min;
					//The value at place runs in the array is set equal to min. This and the previous line of code effectively "switches" two values in the array.
				}
				print(a, 0, length);
				System.out.println("");
				//The array as of now is printed (this is primarily for testing purposes).
				runs=runs+1;
				//runs is raised by 1, so the method disregards all numbers that it has already put in its proper location
				return selectSort(a, runs, val2, 99999, length, runs);
				//The method calls itself. min is set to a massive number to "reset" it, and val1 is set to runs so all numbers that have already been sorted are disregarded.
			}
		}
		else if(a[val1]<min) {
			//If the method has not reached the end of the array, and the value in the array at place val1 is less than min, val2 is set to val1, min, is set to the value in the array at place val1, and the method calls itself, increasing val1 by 1.
			min=a[val1];
			val2=val1;
			return selectSort(a, val1+1, val2, min, length, runs);
		}
		else {			
			//Otherwise, the method calls itself, raising val1 by 1.
			return selectSort(a, val1+1, val2, min, length, runs);
		}
	}
	public boolean checkArray(int[] a, int counter, int length, boolean rightOrder){
		//Method is used to check if all the values in an array are sorted. The parameters are as follows:
		//a: the array you want to check.
		//counter: the current place in the array.
		//length: the length of the array.
		//rightOrder: whether or not the array is in the right order.
		if(counter>=length-1) {
			//If the method reaches the end of the array without anything being in the wrong order, it returns rightOrder, which should be true.
			return rightOrder;
		}
		else if(a[counter]>a[counter+1]) {
			//If the method sees that any numbers are in the wrong order, it sets rightOrder to false and returns it.
			rightOrder=false;
			return rightOrder;
		}
		else {
			//Otherwise, if the last two numbers checked are in the right order, then the method calls itself, increasing counter by 1.
			return checkArray(a, counter+1, length, rightOrder);
		}
		
	}
	public void print(int[] a, int counter, int length) {
		//Method is used to print all the values in an array. The parameters are as follows:
		//a: the array to be printed.
		//counter: the current place in the array.
		//length: the length of the array.
		if(counter>=length) {
			//If the method reaches the end of the array, it returns.
			return;
		}
		else {
			//Otherwise, the method prints the current value in the array and calls itself, raising the counter by 1.
			System.out.println(a[counter]);
			print(a, counter+1, length);
		}
	}
}
