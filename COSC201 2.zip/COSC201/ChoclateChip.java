import java.util.*;

class ChoclateChip {
	private int chipNum;  
			  
		// the Bicycle class has one constructor 
	public ChoclateChip(int newChipNum) 
	{ 
		chipNum = newChipNum;
	} 
	public ChoclateChip() 
	{ 
		chipNum = 0; 
	} 
		  
	// the Bicycle class has three methods 
	  		// toString() method to print info of Bicycle 
	public String toString()  
	{ 
		return("No of chips on the cookie "+ chipNum); 
	}
	public int getChipNum(){
		return chipNum;
	}
	//"Get" methods return the values of the variables used by the interface methods to other classes.
	public void setChipNum(int newChipNum){
		chipNum = newChipNum;
	}
	public int compareTo(ChoclateChip cooks){
		int i = 0;
		if(this.getChipNum() > cooks.getChipNum()){
			i = 1;
			return i;
		}
		else if(this.getChipNum() < cooks.getChipNum()){
			i = -1;
			return i;
		}
		else{
			i = 0;
			return i;
		}
	}
	public <E extends Comparable> E min(ArrayList<E> cook){
		for()
		cook.getIndex
		
	}

}