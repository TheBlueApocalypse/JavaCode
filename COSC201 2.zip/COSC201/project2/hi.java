class hi {
	public static void main(String[] args) {
		int count = 15;
		int mid = 0;
		mid = (count/2)+1;
		System.out.println(mid);
	}
}