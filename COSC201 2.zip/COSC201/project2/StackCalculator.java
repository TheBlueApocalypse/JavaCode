import java.util.*;
class StackCalculator {
	private String input;
	private ArrayList<TupleVar> tups = new ArrayList<TupleVar>();
	
	public void StackCalculator(){
	}
	public void processInput(String s) {
		//printList();
		StackI stackInt = new StackI();  //ment for calculation portion of the calculator
		StackC stackC = new StackC();// postfix portion of the calculator
		Queue queue = new Queue(); //ment for the whole program
		s = cleanTextContent(s);// to enable the clean context and remove all regex Characters
		int leftPCount = 0;// paren count
		int rightPCount = 0;//
		int leftBCount = 0;//brackets count
		int rightBCount = 0;//
		int leftSBCount = 0;//square braces count
		int rightSBCount = 0;//
		int i = 0;
		Boolean valid = true;
		Boolean quit = false;
		String numberWord = "";// ment to catch all the number values in the string that was recived
		Boolean noNonsenceHere = false;
		String varName = "";
		int varValue = 0;
		int consecutiveMinus = 0; 
		Boolean allMinAccount = false;
		TupleVar tup = new TupleVar();
		Boolean changeValue = false;//accounts for repeat vars
		while(valid == true && i < s.length()){
			Character c = s.charAt(i);
			if(compareToVars(c) == true){
				//System.out.println("String length is:" + s.length() + " and index is: " + i);
				if(i+1 < s.length()){
					Character c2 = s.charAt(i+1);
					//System.out.println(c2);
					if(c2 == '='){
						if(checkMem(c) == true){
							varName = Character.toString(c);
							changeValue = true;
							i+=2;
						}
						else{
							varName = Character.toString(c);
							i+=2;
						}
					}// making sure this is not a reassignment and is a replacement for the variable found
					else if(c2 != '='){
						//System.out.println("Variable check at no = sign is: " + checkMem(c));
						//checking for existing vales and making sure the one declared exists
						if(compareToVars(c2) == true){
							System.out.println("Invalid Variable Name: " + c + c2);
							valid = false;
							break;
						}
						if(checkMem(c) == true){
							tup = getMemValue(Character.toString(c));
							String trans = String.valueOf(tup.getVal());
							//System.out.println("this is the value: " + trans);
							
							queue.enqueue(trans);
							i++;
						}
						//if no value exists then the value sumbitted is wrong and the eqution should fail
						else{
							System.out.println("Undefined Variable: " + c);
							valid = false;
						}
					}
				}
				//this last else says if the last value is a variable replace it and make sure no error is thrown
				else{
					//System.out.println("Variable chck when is last in expression is: " + checkMem(c));
					//double checks memory to see if the value exists then adds its true value to queue
					if(checkMem(c) == true){
						tup = getMemValue(Character.toString(c));
						if(tup.getKey() == "true"){
							String trans = String.valueOf(tup.getVal());
							//System.out.println("this is the value: " + trans);
							queue.enqueue(trans);
						}
						else{
							valid = false;
							System.out.println("Undefined Variable: " + c);
						}
						i++;
					}
				}				
			}
			//checks for all numeric values coming through out the the string function
			else if(Character.getNumericValue(c) >= 0 && Character.getNumericValue(c) <= 9){
				numberWord += Character.getNumericValue(c);
				//System.out.println(numberWord);
				//double checks that the postion of the pointer is less than the length
				if(i+1 < s.length()){
					//makes shure that the value of the next value of the string is a struture that makes sense comes next 
					if(compareToArith(s.charAt(i+1)) == true || isRightControl(s.charAt(i+1)) > 0){
						//System.out.println("this is the value going in: " + numberWord);
						queue.enqueue(numberWord);
						numberWord = "";
					}
				}
				//if a number is the last value then append the full number to the list
				else if(i+1 == s.length()){
					//System.out.println("this is the value going in: " + numberWord);
					queue.enqueue(numberWord);
				}
				i++;
			}//going through out the values if the arithmetic ops are found then 
			else if(compareToArith(c)== true){
				Character c2 = s.charAt(i+1);
				if(valueArith(c) == 3 && valueArith(c2)==3){
					//System.out.println("You have made it i is : " + i + "length is: " + s.length());
					c = '^';
					i++;
				}
				//double checks for negatives after a *,/,or %
				else if(valueArith(c) > 2 && valueArith(c2)==2){
					consecutiveMinus++;
					int k = i+2;
					//runs through the string for any other negatives
					while(allMinAccount == false){
						//counts all negatives and moves pointer
						if(valueArith(s.charAt(k)) == 2){
							consecutiveMinus++;
							k++;	
						}
						//when all negatives in this group are found leave
						else{
							allMinAccount = true;
						}	
					}
					if((valueArith(s.charAt(k)) != 2 && valueArith(s.charAt(k)) > 0) && valueArith(s.charAt(k)) == 2){
						valid = false;
						System.out.println("Nonsensical Input1: " + s);
						break;
					}
					//if odd number of negatives add - to number word to create negative value
					else if(consecutiveMinus % 2 == 1){
						numberWord = "-";
						noNonsenceHere = true;
					}
					i = k-1;
				}
				
				//double checks for negatives after -
				else if(valueArith(c) == 2 && valueArith(c2)==2){
					consecutiveMinus+=2;
					int k = i+2;
					//runs through the string for any other negatives
					while(allMinAccount == false){
						//counts all negatives
						if(valueArith(s.charAt(k)) == 2){
							consecutiveMinus++;
							k++;	
						}
						//when all negatives in this group are found leave
						else{
							allMinAccount = true;
						}	
					}
					if((valueArith(s.charAt(k)) != 2 && valueArith(s.charAt(k)) > 0) && valueArith(s.charAt(k)) == 2){
						valid = false;
						System.out.println("Nonsensical Input1: " + s);
						break;
					}
					//negative sign added to stack and queue added to the 0 added to the queue because odd number of negatives == - 
					else if(consecutiveMinus % 2 == 1){
						c = '-';
						if(queue.isEmpty() == true){
							queue.enqueue("0");						
						}
						noNonsenceHere = true;
					}
					//plus sign added to stack and queue added to the 0 added to the queue because even number of negatives == +
					else{
						c = '+';
						if(queue.isEmpty() == true){
							queue.enqueue("0");
							
						}	
						noNonsenceHere = true;			
					}
					i = k-1;
				}//double checks for negatives after +
				else if(valueArith(c) == 1 && valueArith(c2)==2){
					consecutiveMinus++;
					int k = i+2;
					//runs through the string for any other negatives
					while(allMinAccount == false){
						//counts all negatives
						if(valueArith(s.charAt(k)) == 2){
							consecutiveMinus++;
							k++;	
						}
						//when all negatives in this group are found leave
						else{
							allMinAccount = true;
						}	
					}
					//System.out.println(k);
					//System.out.println(s.length());
					if((valueArith(s.charAt(k)) != 2 && valueArith(s.charAt(k)) > 0) && valueArith(s.charAt(k)) == 2){
						valid = false;
						System.out.println("Nonsensical Input1: " + s);
						break;
					}
					//negative sign added to stack and queue added to the 0 added to the queue because odd number of negatives == - 
					else if(consecutiveMinus % 2 == 1){
						c = '-';
						if(queue.isEmpty() == true){
							queue.enqueue("0");

						}
						noNonsenceHere = true;
					}
					//plus sign added to stack and queue added to the 0 added to the queue because even number of negatives == +
					else{
						c = '+';
						if(queue.isEmpty() == true){
							queue.enqueue("0");
						}
						noNonsenceHere = true;
					}
					i = k-1;
				}
				//loops through the values of stack to find operator placement
				while(quit == false){
					//if the stack is empty auto append the new operator to the list
					// checkign for nonsensical input
					if(valueArith(c)>0 && ((valueArith(c2) != 2 && valueArith(c2) > 0) || (valueArith(c2) != 3 && valueArith(c2) > 0)) && noNonsenceHere != true){
						valid = false;
						System.out.println("Nonsensical Input: " + s);
						break;
					}
					else if(stackC.isEmpty() == true){
						//System.out.println("new push" + c);
						stackC.push(c);
						quit = true;
					}
					//if the precidence of the stack value is less than the precidence of the new operator push to stack
					else if(precedence(stackC.peek()) < precedence(c)){
						//System.out.println("new value" + c);
						stackC.push(c);
						quit = true;
					}//if precidence and characters are the same then push the value
					else if((precedence(stackC.peek()) == precedence(c))&& (valueArith(stackC.peek()) == valueArith(c))){
						//System.out.println("new value" + c);
						stackC.push(c);
						quit = true;
					}
					//if the other cheks failed to put it in the stack then remove the value on the stack enqueue it to the queue
					else{
						//System.out.println("enqueingValue" + c);
						queue.enqueue(Character.toString(stackC.pop()));
					}
				}
				i++;
				//reassignment for the next case
				quit = false;	
			}
			// checks the string for any left control strucktures for the 
			else if (isLeftControl(c) > 0) {
				int left = isLeftControl(c);
				//case statement that  finds all lefft control structures for the string
				switch(left) {
					//left bracket count increase and push to stack 
					case 1:
						leftBCount++;
						stackC.push(c);
						break;
					//left square brace count increase and push to stack 
					case 2:
						leftSBCount++;
						stackC.push(c);
						break;
					//left parenthsis count increase and push to stack 
					case 3:
						leftPCount++;
						stackC.push(c);
						break;	
				}	
				i++;
			}
			//checking the values for any  right control values in the string to help properlly create postfix
			else if(isRightControl(c) > 0){
				int right = isRightControl(c);
				switch(right) {
					//checks for each type of the right control structures
					//right bracket count increase and remove all values back to left control structure of the same nature enqueuing all ops 
					case 1:
						rightBCount++;
						//fail case if this right count is greater than the left count
						if(rightBCount > leftBCount){
						System.out.println("Unbalanced Brackets Error, Mismatched Brackets");
						System.out.println(s);
							valid = false;
						}
						//removing all values up to the opposite left control structure
						while(stackC.isEmpty() != true && stackC.peek() != '{') 
						{
							//error check to find mismatch control structures
							if(stackC.peek() == '[' || stackC.peek() == '('){
								valid = false;
								System.out.println("Unbalanced  Brackets Error, Mismatched  Brackets");
								System.out.println(s);
								break;
							}
							else{
								queue.enqueue(Character.toString(stackC.pop()));
							}
							
						}
						//remove left control structure
						if(stackC.peek() == '{'){
							stackC.pop();
						}
						stackC.push(c);
						break;
					//right square brace count increase and remove all values back to left control structure of the same nature enqueuing all ops 
					case 2:
						rightSBCount++;
						//fail case if this right count is greater than the left count
						if(rightSBCount > leftSBCount){
						System.out.println("Unbalanced Square Braces Error, Mismatched Square Braces");	
							valid = false;
						}
						//removing all values up to the opposite left control structure
						while(stackC.isEmpty() != true && stackC.peek() != '['){
							//error check to find mismatch control structures
							if(stackC.peek() == '{' || stackC.peek() == '('){
								valid = false;
								System.out.println("Unbalanced Square Braces Error, Mismatched Square Braces");
								break;
							}
							else{
								queue.enqueue(Character.toString(stackC.pop()));
							}
							
						}
						//remove left control structure
						if(stackC.peek() == '['){
							stackC.pop();
						}
						stackC.push(c);
						break;
					//right parenthsis count increase and remove all values back to left control structure of the same nature enqueuing all ops 
					case 3:
						rightPCount++;
						//fail case if this right count is greater than the left count
						if(rightPCount > leftPCount){
							System.out.println("Unbalanced Parentheses Error, Mismatched Parentheses");
							valid = false;
							break;
						}
						//removing all values up to the opposite left control structure
						while(stackC.isEmpty() != true && stackC.peek() != '('){
							//error check to find mismatch control structures
							if(stackC.peek() == '[' || stackC.peek() == '{'){
								valid = false;
								System.out.println("Unbalanced Parentheses Error, Mismatched Parentheses");
								break;
							}
							else{
								queue.enqueue(Character.toString(stackC.pop()));
							}
						}
						//remove left control structure
						if(stackC.peek() == '('){
							stackC.pop();
						}
						break;
						
				}
				i++;	
			}
			//if any nonsensical value, symbol, or non usable statment comes in fail it
			else{
				valid = false;
				System.out.println("Invalid Symbol: " + c);
				//System.out.println(s);
			}			
		}
		//System.out.println("calculate");
		//System.out.println(valid);
		if(valid == true){
			//fail the valid test if the left cotrol count is greater than the right	
			if(leftPCount > rightPCount){
				valid = false;
				System.out.println("Unbalanced Parentheses Error, Too Many Left Parentheses");
			}
			//fail the valid test if the left cotrol count is greater than the right	
			if(leftBCount > rightBCount){
				valid = false;
				System.out.println("Unbalanced Brackets Error, Too Many Left Brackets");
			}
			//fail the valid test if the left cotrol count is greater than the right	
			if(leftSBCount > rightSBCount){
				valid = false;
				System.out.println("Unbalanced Square Braces Error, Too Many Left Square Braces");
				
			}
			//while(queue.isEmpty() == false){
			//	System.out.println(queue.dequeue());
			//}
			//System.out.println(valid);
			if(valid == true){
				//if the list is empty give it a value of nothing
				if(queue.isEmpty() == true){
					queue.enqueue("0");
				}

			// makes sure to empty the stack into the queue
				while(stackC.isEmpty() == false){
					queue.enqueue(Character.toString(stackC.pop()));
				}
			//System.out.print("this is the post fix notation: ");
			//runs through the length of the queue to calculate the system
				while(queue.isEmpty() == false){
					String temp = queue.dequeue();
					int tempNum = 0;
					int tempCalc = 0;
					//will auto push a number to the stack if valid
					if(checkForNum(temp) == true){
						stackInt.push(Integer.parseInt(temp));
						//System.out.println("pushing to stack");
						//System.out.println(stackInt.peek());
					}//will check for operators when the number finder fails
					else{
						Character tempC = temp.charAt(0);
						//System.out.println(tempC);
						switch (tempC){
							//calculates an addition function
							case '+':
								tempNum = stackInt.pop();
								tempCalc = stackInt.pop() + tempNum;
								stackInt.push(tempCalc);
								break;
							//calculates a subtraction function
							case '-':
								tempNum = stackInt.pop();
								tempCalc = stackInt.pop() - tempNum;
								stackInt.push(tempCalc);
								break;
							//calculates a multiplication function
							case '*':
								tempNum = stackInt.pop();
								tempCalc = stackInt.pop() * tempNum;
								stackInt.push(tempCalc);
								break;
							//calculates a modular function
							case '%':
								tempNum = stackInt.pop();
								tempCalc = stackInt.pop() % tempNum;
								stackInt.push(tempCalc);
								break;
							//calculates a division function
							case '/':
								tempNum = stackInt.pop();
								tempCalc = stackInt.pop() / tempNum;
								stackInt.push(tempCalc);
								break;
							//calculates an exponentail function
							case '^':
								//System.out.println("was an operator and were doing exponents");
								tempNum = stackInt.pop();
								int numBase = stackInt.pop();
								int growingTotal = numBase;
								//multiplies the base by the growing growingTotal for the calculation
								for(int k = 1; k < tempNum; k++){
									growingTotal = growingTotal * numBase;
								}
								tempCalc = growingTotal;
								stackInt.push(tempCalc);
								break;
							default:
								//convert to int
								//System.out.println("was not an operator");
								break;
						}
					}
				}
				//System.out.println(tups.size());
				/*for(int j = 0; j < tups.size(); j++){
					System.out.println("tups vars: " + tups.get(j));
				}*/
				//post fix section
				//System.out.println("showing Var name: " + varName);
				//checks to see if a doesnt exist
				if(varName == ""){
					int total = stackInt.pop();
					System.out.println("THE TOTAL IS: " + total);
				}
				//if variable doesnt exist create new tuple
				else if(varName != "" && changeValue == false){
					varValue = stackInt.pop();
					makeNewMem(varName, varValue);
					System.out.println(varName + " is set to: " + varValue);
				}
				//if variable exists change its value
				else if(changeValue == true){
					varValue = stackInt.pop();
					changeVar(varName, varValue);
					System.out.println(varName + " is now set to: " + varValue);
				}
			}
		}
	}
	//getMemValue will take in a string to find the value pair  and return a tuple for mem verification validity
	//input: string key
	//output:returns a tuple var 
	public Boolean checkMem(Character key)
	{
		if(tups.size() != 0)
		{
			//System.out.println("list is not empty");
			for(int i = 0; i < tups.size(); i++)
			{
				Character c = tups.get(i).getKey().charAt(0);
				if(c == key)
				{
					return true;
				}
			}
		}
		return false;
	}
	//isEmpty will check if the tups list and test if empty
	//input: N/A
	//output:returns a true or false value 
	public Boolean isEmpty()
	{
		if(tups.size() != 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	//getMemValue will take in a string to find the value pair  and return a tuple for mem verification validity
	//input: string key
	//output:returns a tuple var 
	public TupleVar getMemValue(String key)
	{
		Character s = key.charAt(0);
		//runs through the tuple list to find the value
		for(int i = 0; i < tups.size(); i++)
		{
			Character c = tups.get(i).getKey().charAt(0);
			//chekcs to see if the value exists
			if(c == s)
			{
				TupleVar good = new TupleVar("true", tups.get(i).getVal());
				return good;
			}
		}
		TupleVar bad = new TupleVar("false", 0);
		return bad;
	}
	//makeNewMem will create a new variable tuple for the tuple list 
	//input: String key, int value
	//output: N/A
	public void makeNewMem(String keyValue, int intValue){
		TupleVar memoryValue = new TupleVar(keyValue, intValue);
		tups.add(memoryValue);
	}
	//changeVar will change the value of the tuple if the variable tuple has a redeclaration
	//input: String key, int value
	//output: N/A
	public void changeVar(String key, int value){
		Character s = key.charAt(0);
		for(int i = 0; i < tups.size(); i++)
		{
			Character c = tups.get(i).getKey().charAt(0);
			if(c == s)
			{
				tups.get(i).setVar(value);
			}
		}
	}
	//compareToArith will determine if the value sent in is an operator or not
	//input: character c
	//output: Boolean either true or false
	public Boolean compareToArith(Character c){
		Boolean validate = null;
		switch(c) {
			case '+':
			case '-':
			case '*':
			case '/':
			case '%':
			case '^':
				validate = true;
				break;		
			default:
				validate = false;
			
		}
		return validate;
	}
	//valueArith will always asign the usable operators a value
	//input: character c
	//output: int assinged to each operator or the default
	public int valueArith(Character c){
		int validate = 0;
		//compares c to all usable mathematical operators
		switch(c) {
			case '+':
				validate = 1;
				break;
			case '-':
				validate = 2;
				break;
			case '*':
				validate = 3;
				break;
			case '/':
				validate = 4;
				break;
			case '%':
				validate = 5;
				break;
			default:
				validate = -1;				
		}
		return validate;
	}
	//compare to vars is a function that makes sure that you use a logical variable name
	//input:char c
	//output: returns a boolean value of either true or false
	public Boolean compareToVars(Character c){
		Boolean validate = false;
		int ascii = c;
		if(c >= 97 && c <= 122){
			validate = true;
		}
		else if(c >= 65 && c <= 90){
			validate = true;
		}
		return validate;
	}
	//this is a string cleaner that removes all regex characters from it and withe space
	//input:String text
	//output:String value
	public String cleanTextContent(String text) 
	{
		// strips off all non-ASCII characters
		text = text.replaceAll("[^\\x00-\\x7F]", "");
		// erases all the ASCII control charactes
		text = text.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");	
		// removes non-printable characters from Unicode
		text = text.replaceAll("\\p{C}", "");
		//remove whitespace from string
		text = text.replaceAll(" ", "");
		return text.trim();
	}
	// will take in a charater and will return a numeric based on the precidence
	//input: char value
	//output: integer value of the operators precidence
	public int precedence(char c){
		switch (c){
			case '+':
			case '-':
				return 1;
			case '*':
			case '/':
			case '%':
				return 2;
			case '^':
				return 3;
		}
		return -1;
	}
	// will validate weather or not the value sent is a left based control structure
	//input: string value
	//output: true or false depending on outcome
	public Boolean checkForNum(String value){
		Character temp = value.charAt(0);
		// double checks for any number value or negative number value in the string
		if((temp >= 48 && temp <= 57)|| (temp == '-' && value.length() > 1)){
			return true;
		}
		else{
			return false;
		}
	}
	// will validate weather or not the value sent is a left based control structure
	//input: N/A
	//output: The list of variables or no vals
	//public void printList(){
		//if values are found print the whole list
		//if(tups.size() > 0){
			//for(int j = 0; j < tups.size(); j++){
				//tups.get(j).print();
			//}
		//}
	//}
	// will validate weather or not the value sent is a left based control structure
	//input: Character control
	//output: int value
	public int isLeftControl(Character control){
		switch(control) {
			//if left bracket return corrisponding value
			case '{':
				return 1;
			//if left square brace return corrisponding value
			case '[':
				return 2;
			//if left parenthisis return corrisponding value
			case '(':
				return 3;
			//all else fails return base		
			default:
				return 0;
			
		}
	}
	// will validate weather or not the value sent is a right based control structure
	//input: Character control
	//output: int value
	public int isRightControl(Character control){
		switch(control) {
			//if right bracket return corrisponding value
			case '}':
				return 1;
			//if right square brace return corrisponding value
			case ']':
				return 2;
			//if right parenthisis return corrisponding value
			case ')':
				return 3;		
			//all else fails return base
			default:
				return 0;		
			}
		}
}