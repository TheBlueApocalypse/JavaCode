//this is the numeric pre postfix operato stack that is ment to store the characters that are going to be placed onto the queue in the proper postfix notaiton
import java.util.ArrayList;
import java.util.EmptyStackException;
public class StackC {
	private ArrayList<Character> stackList = new ArrayList<Character>();
	//basic default constructor 
	//input: N/a
	//Output: N/A
	public void Stack() {
		System.out.println("hi stack");
	}
	//push function that adds the values to the front of the array list 
	//input: int value
	//Output: N/A
	public void push(Character p){
		stackList.add(0,p);
	}
	//pop function that removes the values to the front of the array list 
	//input: N/A
	//Output: integer value that was removed from the stack.
	public Character pop(){
		return stackList.remove(0);
	}
	//peek is a function that will retreive the first value of the list to show whats in that position without removing it.
	//Input: N/A
	//Output: retrieves the first value of the list to return
	public Character peek(){
		return stackList.get(0);
	}
	// checks to see if this list is empty or not
	//input: N/A
	//Output: returns a true or false value that shows wether or not the list is empty

	public Boolean isEmpty(){
		if(stackList.size() != 0){
			return false;
		}
		else{
			return true;
		}
	}
	// checks to find the size of the list
	//input: N/A
	//Output: returns a numeric value of the list size
	public int size(){
		return stackList.size();
	}
		 //this throws an error
}