//this is the numeric postfix calculation stack that is ment to store the integers that are going to be caulclated into the results

import java.util.ArrayList;
import java.util.EmptyStackException;
public class StackI {
	private ArrayList<Integer> stackList = new ArrayList<Integer>();
	//basic default constructor 
	//input: N/a
	//Output: N/A
	public void StackI() {
		System.out.println("hi stack");
	}
	//push function that adds the values to the front of the array list 
	//input: int value
	//Output: N/A
	public void push(int p){
		stackList.add(0,p);
	}
	//pop function that removes the values to the front of the array list 
	//input: N/A
	//Output: integer value that was removed from the stack.
	public int pop(){
		return stackList.remove(0);
	}
	//peek is a function that will retreive the first value of the list to show whats in that position without removing it.
	//Input: N/A
	//Output: retrieves the first value of the list to return
	public int peek(){
		return stackList.get(0);
	}
	// checks to see if this list is empty or not
	//input: N/A
	//Output: returns a true or false value that shows wether or not the list is empty
	public Boolean isEmpty(){
		if(stackList.size() != 0){
			return false;
		}
		else{
			return true;
		}
	}
	// checks to find the size of the list
	//input: N/A
	//Output: returns a numeric value of the list size
	public int size(){
		return stackList.size();
	}
}