//is designed to take in and remove values for the posfix notaion and calculation
import java.util.ArrayList;
import java.util.EmptyStackException;
public class Queue {
	
	 private ArrayList<String> queueList = new ArrayList<String>();
	//basic deffault constructor for the queue program
	public void Queue() {
		System.out.println("hi queue");
		//instatiates the queues 
	}
	//puting the queue values at the begining of the list so that the dequeue function doesnt have to do any of the hard work.
	public void enqueue(String p){
		queueList.add(0,p);
	}
	// the dequeue fuction removes the end value of the list a
	// input: N/a
	// output: retrns the value that was removed from the list
	public String dequeue(){
		return queueList.remove(queueList.size()-1);
	}
	//peek is a function that will retreive the final value of the list to show whats in that position without removing it.
	//Input: N/A
	//Output: retrieves the final value of the list to return
	public String peek()
	{
		return queueList.get(queueList.size()-1);
		
	}
	// checks to see if this list is empty or not
	//input: N/A
	//Output: returns a true or false value that shows wether or not the list is empty
	public Boolean isEmpty(){
		if(queueList.size() != 0){
			return false;
		}
		else{
			return true;
		}
	}
	// checks to find the size of the list
	//input: N/A
	//Output: returns a numeric value of the list size
	public int size(){
		return queueList.size();
	}	
}
