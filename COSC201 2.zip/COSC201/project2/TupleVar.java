//tuple var is another self created storage value used for the storage of varaible placed into the calculator 
class TupleVar{
	private String key;
	private int value;
	// defaut constructor for the vairable storage system
	//input: N/A
	//Output: N/A
	public TupleVar(){
		key = "";
		value = 0;
	}
	// oveloaded constructor for the vairable storage system
	//input: N/A
	//Output: N/A
	public TupleVar(String k, int v){
		key = k;
		value = v;
	}
	// set tup is a method that allows the user to set a tuples full values if the default constructor was used to make a tuple
	//input: user sends in a string value and an integer attribute
	//output: N/A
	public void setTup(String k, int v){
		key = k;
		value = v;
	}
	// set tup is a method that allows the user to set a tuples full values if the default constructor was used to make a tuple
	//input: user sends in a string value and an integer attribute
	//output: N/A
	public void setVar(int v){
		value = v;
	}
	// set tup is a method that allows the user to set a tuples full values if the default constructor was used to make a tuple
	//input: user sends in a string value and an integer attribute
	//output: N/A
	public String getKey(){
		return key;
	}
	// set tup is a method that allows the user to set a tuples full values if the default constructor was used to make a tuple
	//input: user sends in a string value and an integer attribute
	//output: N/A
	public int getVal(){
		return value;
	}
	// print was orginally for testing but it is usefull for the printing of a variable output value at print time.
	//input: N/A
	//output: pretty prints the values of the variable
	public void print(){
		System.out.println("The variable name is : " + this.key + " the value of the variable is: " + this.value);
	}
	
}