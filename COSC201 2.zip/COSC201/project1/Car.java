abstract class Car {
	// the abstract methods to be implimented across all classes 
	public abstract int getYear();
	public abstract String getMake();
	public abstract String getModel();
  	public abstract void setYear(int year);
	public abstract void setMake(String make);
	public abstract void setModel(String make);
	public abstract int getMPG();
	public abstract void setMPG(int mpg);
	public abstract String toString();
	public abstract double getPrice();
	public abstract void setPrice(double price);
}