import java.util.*;
import java.io.*;
import java.awt.*;
import javax.accessibility.*;


class Driver {
	public static void main(String[] args)throws IOException , FileNotFoundException {
		boolean leave = false;
		String wordFile = "";
		Scanner input = new Scanner(System.in);
		while (leave != true){				//creates a list that will get the words from the file
		ArrayList wordList = new ArrayList();
		System.out.println("Please enter a new txt file name using the .txt at end");
		wordFile = input.next();
		File output = new File(wordFile);
		//create a text file object which you will write the output to
		if (output.length() == 0) {
			System.out.println("File is empty ...");
			System.out.println("Please enter a new txt file name using the .txt at end. The previous was empty");
			wordFile = input.next();
			File output2 = new File(wordFile);
			while(output2.length() == 0 ){
				System.out.println("File is empty ...");
				System.out.println("Please enter a new txt file name using the .txt at end. The previous was empty");
				wordFile = input.next();
				File output3 = new File(wordFile);
				output2 = output3;
			}
			//create a text file object which you will write the output to
			
		}
		File output1 = new File(wordFile);// if statements that determine electric car, hybrid or gas guzzler 
		/*File textFile = new File("carfile.txt");
		
		// creates the file
		textFile.createNewFile();
		
		// creates a FileWriter Object
		FileWriter writerValue = new FileWriter(textFile); 
		
		// Writes the content to the file
		writerValue.write("Ford, Fiesta, 2019, 14260, 37\n Tesla, Roadster, 2008, 38599, true\n MAZDA, Protege, 2003, 3289, 24\n Kia, Optima, 2018, 21357, 37, true\n Lexus, IS, 2020, 38560, 30\n Toyota, Prius, 2001, 4999, 42, false\n Chevy, Volt, 2016, 16296, 42, true\n Nissan, Leaf, 2015, 10228, true\n Honda, Civic, 2010, 6781, 34\n Toyota, Prius Prime, 2017, 21247, 133, true\n Ford, Fusion, 2013, 8462, 41, false"); 
		writerValue.flush();
		writerValue.close();*/
		
		
		String word = "";
		String title = "";
		String make = "";
		String model = "";
		int year = 0;
		double price = 0;
		int mpg = 0;
		Boolean plugIn = null;
		 // Enter the file name to read
		// use a Scanner to read each line of a file
		Scanner scanner = new Scanner(output1);
		while (scanner.hasNextLine()) {
			// create a new string to hold the file line & read it
			String line = scanner.nextLine();
			line = cleanTextContent(line);
			
			Scanner lineScanner = new Scanner(line);
			// set the delimiter
			lineScanner.useDelimiter(", ");
			ArrayList<String> strings = new ArrayList<String>();
			while (lineScanner.hasNext()) {
				// parse each data value from the line
				String part = lineScanner.next();
				strings.add(part);
				// print it
				System.out.print(part + ", ");
			} 
			strings.set(strings.size()-1,cleanTextContent(strings.get(strings.size()-1)));
			// Electric case statments that take in the rest of the values 
			System.out.print("");
			System.out.println(strings.get(strings.size()-1));
			
			if (strings.size()== 5){
				switch(strings.get(strings.size()-1)) {
					case "true":
						// code block
						make = strings.get(0);
						model = strings.get(1);
						year = Integer.parseInt(strings.get(2));
						price = Double.parseDouble(strings.get(3));
						System.out.println("Electric condition met");
						//proves the class will be created
						plugIn = Boolean.parseBoolean(strings.get(4));
						Electric ex = new Electric(price, plugIn, make, model, year);
						wordList.add(ex);
						System.out.print("1");
						break;
					default:
						make = strings.get(0);
						model = strings.get(1);
						year = Integer.parseInt(strings.get(2));
						price = Double.parseDouble(strings.get(3));
						System.out.println("Gas condition met");
						//proves the class will be created
						mpg = Integer.parseInt(strings.get(4));
						GasGuzzler gx = new GasGuzzler(price, mpg, make, model, year);
						wordList.add(gx);
						System.out.print("0");
				}
				
			}
				// hybrid case statments that take in the rest of the values 
			else if (strings.size() == 6){
				make = strings.get(0);
				model = strings.get(1);
				year = Integer.parseInt(strings.get(2));
				price = Double.parseDouble(strings.get(3));
				System.out.println("Hybrid condition met");
				//proves the class will be created
				plugIn = Boolean.parseBoolean(strings.get(5));
				mpg = Integer.parseInt(strings.get(4));
				
				Hybrid hx = new Hybrid(price, plugIn, mpg, make, model, year);
				wordList.add(hx);
			}
			else{
				System.out.println("some thing is wrong with data");
			}           
		System.out.println(); // new line
		}
			//array list=split string by commas
			// take each value if last has bool and 5 electric if 6 Hybrid
			//then append to list
			
	
		System.out.println(wordList);
		//quick sorts
		
		//Car obj = new electric();
		// Shell sort
		
		int n;	
		// print Menu
		System.out.println("Lab 0 - System Menu:");
		System.out.println("Option 1: Shell sort data"); 
		System.out.println("Option 2: Merge sort data"); 
		System.out.println("Option 3: Quick sort data");
		System.out.println("");
		System.out.println("Input an integer for the menu option: "); 
		n = input.nextInt();	
		System.out.println("You entered option " + n);
		if (n == 1){ // print values 0 to X
			shellSort(wordList);
		}
		else if (n == 2){ 
			mergeSort(wordList);
			System.out.println("");
			System.out.println("Merge sort values in order");
			for(int x = 0; x < wordList.size(); x++)
			{
				System.out.println("Position " + (x+1) + " value: " + wordList.get(x).toString());
			}
		}
		else {
			quickSort(wordList, 0, wordList.size()-1);
			System.out.println("");
			System.out.println("Qiuck sort values in order");
			for(int x = 0; x < wordList.size(); x++)
			{
				System.out.println("Position " + (x+1) + " value: " + wordList.get(x).toString());
			}
		}
		System.out.println(" would you like to leave");
		System.out.println("Option 1: For yes Enter 1"); 
		System.out.println("Option 2: For no Enter 2");
		n = input.nextInt();
		if(n == 1){
			leave = true;
		}

		}
		
		//quick sort
		
		
	}

//future portions will be able to sort each list based on user specs

//reads each list as a unit and then compares by mpg
	static<E extends Car> void quickSort(ArrayList<E> arr, int start, int end){
		// does a recursive call for quick sort and the pivot points.
		int partition = partition(arr, start, end);
		//System.out.println("1");
	
		if(partition-1>start) {
			quickSort(arr, start, partition - 1);
		}
		if(partition+1<end) {
			quickSort(arr, partition + 1, end);
		
		}
		//System.out.println("9");
	}
	//each of these methods will sort the vehicles interms of the fastest or the cheapest mind you there will be 2 of each sort.
	static<E extends Car> int partition(ArrayList<E> arr, int start, int end){
		int pivot = arr.get(end).getMPG();
		double pivot2 = arr.get(end).getPrice();
		int pivot3 = arr.get(end).getMPG();
		//System.out.println("2");
		// moves numberrs around the pivot to st up for the next pivot
		for(int i=start; i<end; i++){
			if(arr.get(i).getMPG()>pivot){
				arr.add(null);
				arr.set(arr.size()-1,arr.get(start));
				//System.out.println(arr.get(i));
				arr.set(start,arr.get(i));
				//System.out.println(arr.get(start));
				arr.set(i,arr.get(arr.size()-1));
				arr.remove(arr.size()-1);
				start++;
			}
			else if(arr.get(i).getMPG() == pivot && arr.get(i).getPrice() < pivot2){
				arr.add(null);
				arr.set(arr.size()-1,arr.get(start));
				//System.out.println(arr.get(i));
				arr.set(start,arr.get(i));
				//System.out.println(arr.get(start));
				arr.set(i,arr.get(arr.size()-1));
				arr.remove(arr.size()-1);
				start++;
			}
			else if(arr.get(i).getMPG() == pivot && arr.get(i).getPrice() == pivot2 && arr.get(i).getYear() < pivot3){
				arr.add(null);
				arr.set(arr.size()-1,arr.get(start));
				//System.out.println(arr.get(i));
				arr.set(start,arr.get(i));
				//System.out.println(arr.get(start));
				arr.set(i,arr.get(arr.size()-1));
				arr.remove(arr.size()-1);
				start++;
			}
		}
		// finishes the pivot sort
		//System.out.println("5");
		arr.add(null);
		//System.out.println(arr.get(arr.size()-1));
		arr.set(arr.size()-1,arr.get(start));
		arr.set(start,arr.get(end)); 
		arr.set(end,arr.get(arr.size()-1));
		arr.remove(arr.size()-1);
		 
		return start;
	}
	static <E extends Car> void shellSort(ArrayList<E> arr){
		//ArrayList<T> arr = new ArrayList<T>();
		//arr = 
		int n = arr.size();
		// creates the shell gaps ad sorts by gap
		for (int gap = n/2; gap > 0; gap /= 2) {
			for (int i = gap; i < n; i+= 1) {
				int temp = arr.get(i).getMPG();
				double temp2 = arr.get(i).getPrice();
				int temp3 = arr.get(i).getYear();
				E c1 = arr.get(i);
				//System.out.println(arr.get(i));
				int j;
				
				for (j = i; j >= gap && arr.get(j-gap).getMPG() < temp; j -= gap){
					if(arr.get(j-gap).getMPG() == temp && arr.get(j-gap).getPrice() < temp2){
						//System.out.println("2");
						String word = "";
						word = arr.get(j).toString();
						System.out.println(word);
						arr.set(j,arr.get(j-gap));
					}
					else if(arr.get(j-gap).getMPG() == temp && arr.get(j-gap).getPrice() == temp2 && arr.get(j-gap).getYear() < temp3){
						System.out.println("3");
						String word = "";
						word = arr.get(j).toString();
						System.out.println(word);
						arr.set(j,arr.get(j-gap));
					}
					else if(arr.get(j-gap).getMPG() < temp){
						//System.out.println("1");
						//String word = "";
						//word = arr.get(j).toString();
						//System.out.println(word);
						arr.set(j,arr.get(j-gap));
					}
					
					
				}
				arr.set(j,c1);
			}
		}
		
		// shows the work of the shell sort
		System.out.println("Shell Sort values in order");
		for(int x = 0; x < n; x++)
		{	
			
			System.out.println("Position " + (x+1) + " value: " + arr.get(x));
		}
		
	}
	static String cleanTextContent(String text) 
	{
		// strips off all non-ASCII characters
		text = text.replaceAll("[^\\x00-\\x7F]", "");

		// erases all the ASCII control characters
		text = text.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");
	
		// removes non-printable characters from Unicode
		text = text.replaceAll("\\p{C}", "");
	
		return text.trim();
	}
	static<E extends Car> ArrayList mergeSort(ArrayList<E> arr) {
		ArrayList<E> left = new ArrayList<E>();
		ArrayList<E> right = new ArrayList<E>();
		int center;
	 
		if (arr.size() == 1) {    
			return arr;
		} else {
			center = arr.size()/2;
			// copy the left half of arr into the left.
			for (int i=0; i<center; i++) {
					left.add(arr.get(i));
			}
	 
			//copy the right half of arr into the new arraylist.
			for (int i=center; i<arr.size(); i++) {
					right.add(arr.get(i));
			}
	 
			// Sort the left and right halves of the arraylist.
			left  = mergeSort(left);
			right = mergeSort(right);
	 
			// Merge the results back together.
			merge(left, right, arr);
		}
		return arr;
	}
	static <E extends Car> void merge(ArrayList<E> left, ArrayList<E> right, ArrayList<E> arr) {
		int leftIndex = 0;
		int rightIndex = 0;
		int arrIndex = 0;
	 
		// As long as neither the left nor the right ArrayList has
		// been used up, keep taking the smaller of left.get(leftIndex)
		// or right.get(rightIndex) and adding it at both.get(bothIndex).
		while (leftIndex < left.size() && rightIndex < right.size()) {
			if (left.get(leftIndex).getMPG() > right.get(rightIndex).getMPG()) {		
				arr.set(arrIndex, left.get(leftIndex));
				leftIndex++;
				
			}
			else if(left.get(leftIndex).getMPG() == right.get(rightIndex).getMPG() && left.get(leftIndex).getPrice() < right.get(rightIndex).getPrice()){
				arr.set(arrIndex, left.get(leftIndex));
				leftIndex++;
			}
			else if(left.get(leftIndex).getMPG() == right.get(rightIndex).getMPG() && left.get(leftIndex).getPrice() == right.get(rightIndex).getPrice() && left.get(leftIndex).getYear() >= right.get(rightIndex).getYear()){
				arr.set(arrIndex, left.get(leftIndex));
				leftIndex++;
			}

			else if (left.get(leftIndex).getMPG() <= right.get(rightIndex).getMPG()){
				arr.set(arrIndex, right.get(rightIndex));
				rightIndex++;
				
			}
			else if(left.get(leftIndex).getMPG() == right.get(rightIndex).getMPG() && left.get(leftIndex).getPrice() >= right.get(rightIndex).getPrice()){
				arr.set(arrIndex, right.get(rightIndex));
				rightIndex++;
			}
			else if(left.get(leftIndex).getMPG() == right.get(rightIndex).getMPG() && left.get(leftIndex).getPrice() == right.get(rightIndex).getPrice() && left.get(leftIndex).getYear() < right.get(rightIndex).getYear()){
				arr.set(arrIndex, right.get(rightIndex));
				rightIndex++;
			}
			arrIndex++;
		}
	 
		ArrayList<E> rest;
		int restIndex;
		if (leftIndex >= left.size()) {
			// The left ArrayList has been use up...
			rest = right;
			restIndex = rightIndex;
		} else {
			// The right ArrayList has been used up...
			rest = left;
			restIndex = leftIndex;
		}
	 
		// Copy the rest of whichever ArrayList (left or right) was not used up.
		for (int i=restIndex; i<rest.size(); i++) {
			arr.set(arrIndex, rest.get(i));
			arrIndex++;
		}
	}
	
}
