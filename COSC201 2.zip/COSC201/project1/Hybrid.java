class Hybrid extends Car{
	private double price; 
	private boolean plugIn; 
	private int mpg;
	private String model;
	private String make;
	private int year;
	//The variables used in this class are declared.
	public Hybrid() {
		//First constructor sets a "default" value to every variable in the program.
		price=0;
		plugIn=false;
		model="Default tagline";
		make="Unknown";
		year=0;
	}
	public Hybrid(double p, boolean pg, int mg, String ma,  String mo, int y) {
		//Second constructor allows the user to manually input values for each variable.
		price=p;
		plugIn=pg;
		mpg = mg;
		model=mo;
		make=ma;
		year=y;
	}
public double getPrice(){
	return price;
}
public boolean getPlugIn(){
	return plugIn;
}
public int getMPG(){
	return mpg;
}

public String getModel(){
	return model;
}
//"Get" methods return the values of the variables used by the interface methods to other classes.
public void setPrice(double newPrice){
	price = newPrice;
}
//The price is equal to the input from the driver.
public void setPlugIn(boolean newPlugIn){
	plugIn = newPlugIn;
}
public void setMPG(int newMPG){
	mpg = newMPG;
}
//The PlugIn is equal to the input from the driver.
public void setModel(String newModel){
	model = newModel;
}
//"Set" methods take in values from the driver for the interface methods and store them in this class.
public String getMake() {
	return make;
}
public int getYear() {
	return year;
}
//"Get" methods return the values of each exclusive variable to the driver.
public void setMake(String newMake) {
	make = newMake;
}
public void setYear(int newYear) {
	year = newYear;
}
//"Set" methods take in values exclusive to this class from the driver and store them in this class.
public String toString() { 
//This method returns the values of each variable to other classes in a form that can be easily printed.
	return "Car [Price: " + price + "$, MPG: " + mpg + " Plug In: " + plugIn + ", Make: " + make +", Model: " + model + ", Year of model: "+year+"] ";
}
}