class Electric extends Car{
	private double price; 
	private boolean plugIn; 
	private String model;
	private String make;
	private int year;
	private int mPG;
	//The variables used in this class are declared.
	public Electric() {
		//First constructor sets a "default" value to every variable in the program.
		price=0;
		plugIn= true;
		model="Default tagline";
		make="Unknown";
		year=0;
		mPG = 10000;
	}
	public Electric(double p, boolean pg, String ma,  String mo, int y) {
		//Second constructor allows the user to manually input values for each variable.
		price=p;
		plugIn=pg;
		model=mo;
		make=ma;
		year=y;
		mPG = 10000;
		
	}
	public int getMPG(){
		return mPG;
	}
	public void setMPG(int mpg){
		mPG = mpg;
	}
	public double getPrice(){
		return price;
	}
	public boolean getPlugIn(){
		return plugIn;
	}
	public String getModel(){
		return model;
	}
//"Get" methods return the values of the variables used by the interface methods to other classes.
	public void setPrice(double newPrice){
		price = newPrice;
	}
//The price is equal to the input from the driver.
	public void setPlugIn(boolean newPlugIn){
		plugIn = newPlugIn;
	}
//The PlugIn is equal to the input from the driver.
	public void setModel(String newModel){
		model = newModel;
	}
	//"Set" methods take in values from the driver for the interface methods and store them in this class.
	public String getMake() {
		return make;
	}
	public int getYear() {
		return year;
	}
	//"Get" methods return the values of each exclusive variable to the driver.
	public void setMake(String newMake) {
		make = newMake;
	}
	public void setYear(int newYear) {
		year = newYear;
	}
	//"Set" methods take in values exclusive to this class from the driver and store them in this class.
	public String toString() { 
	//This method returns the values of each variable to other classes in a form that can be easily printed.
	return "Car [Price: " + price + "$, Plug In: " + plugIn + ", Make: " + make +", Model: " + model + ", Year of model: "+year+"] ";
	}
}