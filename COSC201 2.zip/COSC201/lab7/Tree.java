5/***
 * Tree class
 * Creates a balanced binary search tree and prints it in three different ways
 * Written by William Capon and Cameron Carpenter for Lab 7
 * 4/7/2020
 */

import java.util.*;
class Tree {
	private Node treeRoot;
	
	public Tree(int height){
		treeRoot = new Node(calcNodeNum(height)); //Set the root (could be any number, tidier this way)
		createNode(height,1,treeRoot); //Generate the tree
	}
	
	/***
	 * Returns the number of nodes in a table of height h
	 * @param height
	 * @return
	 */
	public int calcNodeNum(int height){
		int numberOfNodes;
		numberOfNodes = (int)Math.pow(2, height);
		numberOfNodes--;
		return numberOfNodes;
	}
	
	
	/***
	 * Recursively creates a balanced binary search tree, given a root node
	 * @param height The height of the desired tree
	 * @param level Current level of the process, starts at 1
	 * @param previousVal The previous node.  Start with root
	 */
	public void createNode(int height,int level,Node previousVal) {
		if(level == height) { //Safeguard for table height of 1
			return;
		}
		int under = calcNodeNum(height-level); //Number of nodes under this
		
		//Insert left and right nodes
		insertRec(treeRoot,previousVal.getNum()-under);
		insertRec(treeRoot,previousVal.getNum()+under);
		
		//Call method for following nodes if they aren't supposed to be leaves yet
		if(level < height-1) {
			createNode(height,level+1,previousVal.getLeft());
			createNode(height,level+1,previousVal.getRight());
		}
	}
	
	/* A recursive function to insert a new key in BST */
	Node insertRec(Node root, int key) { 
			/* If the tree is empty, return a new node */
		if (root == null) { 
			return new Node(key); 
		} 
	  
		/* Otherwise, recur down the tree */
		if (key < root.num) 
			root.left = insertRec(root.getLeft(), key); 
		else 
			root.right = insertRec(root.getRight(), key); 
	  
		/* return the (unchanged) node pointer */
		return root; 
	} 
	
	/**
	 * Prints a tree starting at node current to the bottom in infix notation
	 * @param current
	 */
	public void InOrder(Node current) {
		if(current != null) {
			InOrder(current.getLeft());
			System.out.print(current.getNum() + " ");
			InOrder(current.getRight());
		}
	}
	
	/**
	 * Prints a tree starting at node current to the bottom in prefix notation
	 * @param current
	 */
	public void PreOrder(Node current){
		if(current != null){ 
			System.out.print(current.getNum() + " "); 
			PreOrder(current.getLeft()); 
			PreOrder(current.getRight()); 
		} 
	}
	
	/**
	 * Prints a tree starting at node current to the bottom in postfix notation
	 * @param current
	 */
	public void PostOrder(Node current) {
		if(current != null) {
			PostOrder(current.getLeft());
			PostOrder(current.getRight());
			System.out.print(current + " ");
		}
	}
	
	public static void main(String[] args) {
		//Get the height
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter a height for the binary search tree:");
		int input = scan.nextInt();
		
		while(input <= 0) { //Validate input
			System.out.println("Please enter a valid height!");
			input = scan.nextInt();
		}
		
		Tree myTree = new Tree(input); //Make tree
		
		//Get printing method
		System.out.println("Please enter a method to use in printing the tree (prefix,infix, or postfix):");
		String order;
		while(true) {
			order = scan.next();
			order = order.toLowerCase();
			//Print prefix
			if(order.contentEquals("prefix")) {
				myTree.PreOrder(myTree.treeRoot);
				break;
			}
			//Print infix
			if(order.contentEquals("infix")) {
				myTree.InOrder(myTree.treeRoot);
				break;
			}
			//Print postfix
			if(order.contentEquals("postfix")) {
				myTree.PostOrder(myTree.treeRoot);
				break;
			}
			//Nothing triggered, ask again
			System.out.println("Please provide a valid method!");
		}
		scan.close();
	}


}