#Will and Cam
#This should operate as a python-themed hangman type game. It shows wins and losses and gives the user 5 tries to guess correctly
#The game is case insensitive.

import random #used to choose the word for hangman


def blank(ans): #blankWord takes in the selected key string and makes a corresponding string of "_"'s the same number of characters long. This string is modified as the user guesses letters
    new = "" #making a new empty string to store the blank word
    for i in ans:
        new += "_"

    return new

def guess_word(guess, old, key):#guessWord method creates a New string with a guess char, Old string, and Key string. The new  is built to reflect either a new letter added to the old string (in the case of a correct guess
    #or the same old string if the guess is wrong
    new = ""
    count = 0 #used to access string indices
    for i in key: #this loop checks the guess letter with those letters in the key word.
        
        if guess.lower() == i.lower(): #if the guess is correct, add it to the new string
            new += guess
        elif old[count].lower() == key[count].lower(): #in the case of a previous correct guess, simply add in the letter from the old string to the new string
            new += key[count]
        elif guess.lower() != key[count].lower(): #if the guess is incorrect and this index was blank before, add another underscore
            new += "_"

        count += 1

    return new

bank = ["WeaklyTyped", "function", "class", "dictionaries","elif", "def()", "init()", "numerics"
       , "LEGB", "GuidoVanRossum", "MontyPythonsFlyingCircus", "ABC", "MachineLearning", "print()", 
       "ForBlankInBlank", "interpreted", "wrapper", "module"]

guess = '' #the users guess
answer = 1
win = 0
loss = 0

while answer == 1:
    print("wins: ", win) #printing wins/ losses from the previous game
    print("losses", loss)
    print()

    wrong = 0 #num of wrong guesses
    tally = 6 #tally of incorerect guesses
    
    keyword = random.choice(bank) #the key word that the user is attempting to guess
    
    guess_string = blank(keyword) #making a string of underscores the same number of characters as the key word
   

    while(guess_string.lower() != keyword.lower() and wrong < 6):  
        tally = 6 - wrong #updating the incorrect guess tally

        print("you have ", tally, " incorrect guesses left")
        print(guess_string)
        print('please guess a letter')

        guess = input() #the character guessed by the user

        s3 = guess_string #a copy of guess string to be put through guess_word
        guess_string = guess_word(guess, s3, keyword)

        if(guess_string == s3):
            wrong += 1

    if wrong < 6 :#printing the 
        print()
        print("congrats, you guessed correctly! The word was", keyword)
        print()
        win += 1
    else:
        print()
        print("you have lost, the word was", keyword)
        print()
        loss += 1

print("wins: ", win)
print("losses", loss)
print("game over")