import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
/*
 * Name: Cameron Carpenter
 * Date: 4/22/20
 * Starter code for the Dijkstra lab
 * 	- Reads in graph and stores in in 2D array. 
 * 	- Sets up Distance and Visited arrays.
 * 
 * Author: Ariel Webster
 * Created 4/14/20
 * 
 * So far everything has been done in the constructor. 
 * You should complete the code in one or more methods. 
 * Do not continue to work in the constructor. 
 * 
 * MAKE SURE TO ADD COMMENTS THROUGHOUT THE CODE
 */

public class Dijkstra {
	public int [][] Graph; // ADD COMMENTS HERE
	public int distance []; // ADD COMMENTS HERE
	public boolean visited []; // ADD COMMENTS HERE
	private int size;
	public int distances [];
	
	public Dijkstra(String filename){
		Scanner scan = null;
	    try{
			scan = new Scanner(new FileReader(filename)); // take in the file
			
		    	int nodes = scan.nextInt(); // the first integer in the file is the number of nodes 
				size = nodes;
				distances = new int[nodes];
		    	Graph = new int[nodes][nodes]; // which can be used to set the sizes of the graph
		    	distance = new int[nodes]; //the distance array
		    	visited = new boolean[nodes]; // and the visited array
		    	
		    	//loops through the places in the graph adding edge weights
		    	//also initializes distance and visited arrays
		    for(int i = 0; i < nodes; i++){
		    		distance[i] = Integer.MAX_VALUE; // sets distance of each node to largest value that can be stored in an integer, which for this lab is close enough to infinity
		    		visited[i] = false; // sets visited to false.
		    		for(int j = 0; j < nodes; j++){
		    			 if(scan.hasNext()){
		       			  Graph[i][j] = scan.nextInt();
		    			 }
		    		}
		    }
 
	    } catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally{
			if(scan != null){
				scan.close();
			}
       }
		
	}

	public static void main(String args[]){
		Dijkstra d = new Dijkstra("Graph2.txt"); //passes the name of the file to the constructor that will initialize all of our class variables
		d.Dijkstra();// ADD COMMENTS HERE
		System.out.println("hi");
	}
	//Dijkstra() goes throught the top half of the diagonal in the graph values and sends it off to change the distance values from the first value
	//input: N/A
	//output: completed distances from the graph travesral
	//complete this method to implement Dijkstra's Algorithm
	public void Dijkstra(){
		for(int i = 0; i+1 < size; i++){// loops trough each row except for the final row
			for(int j = i+1; j < size; j++){ //loops trough each collumn to the right of the diagonal excludina ll reeated values
				if(Graph[i][j] > 0){
					//checks for any connections to other nodes
					UpdateNeighbors(Graph[i][j], j, i);
				}
			}
		}//prints the distances once the calculation is completed
		for(int i = 0; i < distances.length; i++){
			System.out.println("Position" + i + " is " + distances[i] + " away from the start");
		}
		//Make sure to heavily comment your code
	}
	// complete this method so that it updates the distances of all neighbors of the node,
	// the current node, passed into it
	//UpdateNeighbors(int currentVal, int columNum, int rowNum): changes the distances to the shorest path from the root
	//input: the current value being sent in, the colum value, and the row value
	//output: completed distances from the graph travesral
	public void UpdateNeighbors(int currentVal, int columNum, int rowNum){
		//will t
		//move from current row down to the row where point X is and change the value of the distance
		if(distances[columNum] > distances[rowNum] + currentVal){// 
			distances[columNum] = distances[rowNum] + currentVal;
		}
		//changes the value if the distance is the base except for the root
		else if(distances[columNum] == 0 && columNum != 0){
			distances[columNum] = distances[rowNum] + currentVal;
		}
		//Make sure to heavily comment your code
	}
}