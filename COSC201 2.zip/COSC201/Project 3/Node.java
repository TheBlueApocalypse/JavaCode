class Node {
	public int num;
	public int height;
	public Node left;
	public Node right;

	public Node(int d) {
		num = d;
		height = 1;
	}
}
