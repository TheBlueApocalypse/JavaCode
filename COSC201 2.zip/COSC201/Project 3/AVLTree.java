import java.util.*;
import java.io.*;
//
// Cameron Carpenter
//
class AVLTree {
	public Node tree;
	public AVLTree(){
		// System.out.println("You made the base for a tree");
	}
	// height gives acces to the nodes function through Generics
	// input: Node N
	// output: the value of the node's height
	public int height(Node N) {
		if (N == null)//to avoid errors and to compensate for leaf nodes
			return 0;
		return N.height;
	}
	// bigger finds the bigger values and returns it
	// input: int a, int b
	// output: the bigger value int is returned
	public int bigger(int a, int b) {
		if (a > b){
			return a;
		}
		else{
			return b;
		}
	}
	// rightRotate will rotate all values from a right ward stand point
	// input: Node N
	// output: the new node that sits at the top
	public Node rightRotate(Node y) {
		Node x = y.left;
		Node temp = x.right;

		x.right = y;
		y.left = temp;
		//changing the heights of the node values
		y.height = bigger(height(y.left), height(y.right)) + 1;
		x.height = bigger(height(x.left), height(x.right)) + 1;

		return x;
	}
	// leftRotate will rotate all values from a left ward stand point
	// input: Node N
	// output: the new node that sits at the top
	public Node leftRotate(Node x) {
		Node y = x.right;
		Node temp = y.left;

		y.left = x;
		x.right = temp;
		//changing the heights of the node values
		x.height = bigger(height(x.left), height(x.right)) + 1;
		y.height = bigger(height(y.left), height(y.right)) + 1;

		return y;
	}
	// calcBalance will calculate the values
	// input: Node N
	// output: the value of the node's height
	public int calcBalance(Node N) {
		if (N == null)
			return 0;
		return height(N.left) - height(N.right);
	}
	// insert will insert a new value in to the tree while balancing the tree
	// input: Node N
	// output: the value of the node's height
	public Node insert(Node current, int num) {
		//checking for the proper spot for the new node and a 
		if (current == null)
			return (new Node(num));
		// will traverse left side of the tree till spot is found
		if (num < current.num)
			current.left = insert(current.left, num);
		// will traverse left side of the tree till spot is found
		else if (num > current.num)
			current.right = insert(current.right, num);
		// will traverse left side of the tree till spot is found
		else{
			System.out.println("You cannot add this value to the tree. It already exists. :(");
			return current;
		}

		current.height = 1 + bigger(height(current.left), height(current.right));
		
		int balanceVal = calcBalance(current);
		// checks to see if right rotation is necisary
		if (balanceVal > 1) {
			if (num < current.left.num) {
				return rightRotate(current);
			// checks to see if right left rotation is necisary
			} else if (num > current.left.num) {
				current.left = leftRotate(current.left);
				return rightRotate(current);
			}
		}
		// checks to see if left rotation is necisary
		if (balanceVal < -1) {
			if (num > current.right.num) {
				return leftRotate(current);
			// checks to see if a left right rotation is necisary
			} else if (num < current.right.num) {
				current.left = rightRotate(current.left);
				return leftRotate(current);
			}
		}
		return current;
	}
	// minValueNode finds the node with the smallest value
	// input: Node nName
	//output: returns the left most node
	public Node minValueNode(Node nName) {
		Node current = nName;
		//loops throught the whole tree
		while (current.left != null)
			current = current.left;

		return current;
	}
	// lookUp will find a specific node in the tree
	// input: Node current, int num, boolean found
	// output: a true or false variable signifying that the value is in the list
	public boolean lookUp(Node current, int num, boolean found){
		//makes sure that leaf extensions dont interfere with the values of the search
		if(current != null){
			found = lookUp(current.left, num, found);
			found = lookUp(current.right, num, found);
			//signinfies that the falue was found
			if(found == true)
				return true;
			//the value is just found now
			else if(current.num == num){
				System.out.println("The value is in the tree");
				return true;
			}
			//value not in tree
			else if(current == tree && found == false){
				System.out.println("The value is not in the tree");
				return false;
			}
		}
		//empty tree checker
		else if(tree == null){
			System.out.println("This is an empty tree. Please add values first.");
			return false;
		}
		return found;
	}
	// delete will remove a specified value form the list
	// input: Node N, int num
	// output: node to 
	public Node delete(Node tree, int num) {
		//double checks for value not found empty list or end condidtion
		if (tree == null){
			return tree;
		}
		//going down the left side of the tree
		if (num < tree.num)
			tree.left = delete(tree.left, num);
		//going down the right side of the tree
		else if (num > tree.num)
			tree.right = delete(tree.right, num);
		//if value exists then it is goig through the deletion process
		else {
			//leaf values for deletion
			if ((tree.left == null) || (tree.right == null)) {
				Node temp = null;
				//left side null
				if (temp == tree.left)
					temp = tree.right;
				//right side null
				else
					temp = tree.left;
				//removal of values and making sure the new value holds the same values
				if (temp == null) {
					temp = tree;
					tree = null;
				} else
					tree = temp;
			//if the value is higher in the tree help balance it
			} else {
				Node temp = minValueNode(tree.right);

				tree.num = temp.num;

				tree.right = delete(tree.right, temp.num);
			}
			//System.out.println("The value was found and removed");	
		}
		//double checks for value not found empty list or end condidtion
		if (tree == null){
			//System.out.println("This is an empty list or the value was not found.");
			return tree;
		}
		//prep for balancing
		tree.height = bigger(height(tree.left), height(tree.right)) + 1;

		int balanceVal = calcBalance(tree);
		//balance right side
		if (balanceVal > 1) {
			//single right rotate
			if (calcBalance(tree.left) >= 0) {
				return rightRotate(tree);
			//right left rotate
			} else {
				tree.left = leftRotate(tree.left);
				return rightRotate(tree);
			}
		}
		//balance left side
		if (balanceVal < -1) {
			//single left rotate
			if (calcBalance(tree.right) <= 0) {
				return leftRotate(tree);
			//left right rotate
			} else {
				tree.right = rightRotate(tree.right);
				return leftRotate(tree);
			}
		}
		return tree;
	}
	// preOrder prints the tree root left right
	// input: Node current
	// output: N/A
	public void preOrder(Node current) {
		if (current != null) {
			System.out.print(current.num + " ");
			preOrder(current.left);
			preOrder(current.right);
		}
	}
	// inOrder prints the tree left root right
	// input: Node current
	// output: N/A
	public void inOrder(Node current) {
		if(current != null) {
			inOrder(current.left);
			System.out.print(current.num + " ");
			inOrder(current.right);
		}
	}
	// print is a function that calls both the in order and pre order calls
	// input: Node current
	//output: N/A
	public void print(Node current){
		System.out.println("In Order Traversal:");
		System.out.println("-------------------");
		inOrder(current);
		System.out.println();
		System.out.println("Pre Order Traversal:");
		System.out.println("--------------------");
		preOrder(current);
		System.out.println();
	}
	// printer specailty printer that visully represents the tree
	// input: Node current,String spacing, boolean indentEnd 
	// output: N/A
	public void printer(Node current, String spacing, boolean indentEnd) {
			if(current != null) {
				//System.out.println(spacing);
				if(indentEnd == true){
					System.out.println(spacing + "Right: " + current.num);		
					spacing+= "  ";
				}
				else if(current == tree && indentEnd == false){
					System.out.println(spacing + "Root: " + current.num);		
					spacing+= "| ";
				}
				else{
					System.out.println(spacing + "Left: " + current.num);		
					spacing+= "| ";
				}
				printer(current.left, spacing, false);
				printer(current.right, spacing, true);
			}
		}
	// main gives acces to the nodes function through Generics
	// input: Node N
	// output: the value of the node's height
	public static void main(String[] args) {
		AVLTree value = new AVLTree();
		Scanner input = new Scanner(System.in);
		System.out.print("Please enter a valid number of how many elements you want to add: ");
		int loopingNum = input.nextInt();
		//looping mechanism that runs through the number of nodes for the tree
		for(int i = 1; i <= loopingNum; i++){
			System.out.print("> ");
			int insertVal = input.nextInt();
			value.tree = value.insert(value.tree, insertVal);
		}
		int i = 0;
		//runs the looping structure for the user to remove values
		while(i!= 5){
			System.out.println();
			System.out.println("Enter 1 to insert a new value into the tree");
			System.out.println("Enter 2 to delete a value from the tree");
			System.out.println("Enter 3 to lookUp a value from the tree");
			System.out.println("Enter 4 to print all the values from the tree");
			System.out.println("Enter 44 to print a the tree (extra credit)");
			System.out.println("Enter 5 to quit");
			System.out.print("> ");
			int values = input.nextInt();
			System.out.println();
			System.out.println();
			//executes an insert fuction
			if(values == 1){
				System.out.print("Please enter a value to insert: ");
				int newVal = input.nextInt();
				value.tree = value.insert(value.tree, newVal);
			//executes a delete function
			}else if(values == 2){
				System.out.print("Please enter a value to delete: ");
				int search = input.nextInt();
				boolean found = false;
				found = value.lookUp(value.tree, search, found);
				//allowed delet function
				if(found == true){
					// System.out.println("Found the value");
					int delVal = search;
					value.tree = value.delete(value.tree, delVal);
					System.out.println("Deleted the value");
				}
				//says we cant delete
				else{
					System.out.println("Value not found, cannot be deleted.");
				}
				
			//executes a search function
			}else if(values == 3){
				System.out.print("Please enter a value to find: ");
				int search = input.nextInt();
				boolean found = false;
				found = value.lookUp(value.tree, search, found);
				if(found == true){
					System.out.println("Found the value");
				}
				else{
					System.out.println("Value not found");
				}
			//basic printer function
			}else if(values == 4){
				value.print(value.tree);
			//extra credit printer allows up to 64 nodes in the tree
			}else if(values == 44){
				if(value.height(value.tree) < 7)
					value.printer(value.tree, "", false);
			//quit function
			}else if(values == 5){
				i = 5;
			//looper
			}else{
				System.out.println("Invalid number, please try again");
			}
		}
	}
}