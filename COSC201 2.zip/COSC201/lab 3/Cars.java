class Cars extends Vehicle {
	//unique method get mak/ model
		//set all unique values
		//get all generic values
		//create a constructor for no values and all values assigned
		// create getters and setters for the unique values
		//create a to string method
	private String make; 
	private String model;
	public Cars(double inPrice, int inSpeed, String inTagLine, String inMake, String inModel){ 
		super(inPrice, inSpeed, inTagLine);
		make = inMake;
		model = inModel;
	} 
	public Cars(){ 
		super();
		make = "";
		model = "";
	}
	public String getMake(){
		return make;
	}
	public String getBusType(){
		return model;
	}
	public void setNumOfSeats(String newMake){
		make = newMake;
	}
	public void setBusType(String newModel){
		model = newModel;
	}
	public String toString(){ 
		return super.toString() + " " + make + " " + model; 
	}
}