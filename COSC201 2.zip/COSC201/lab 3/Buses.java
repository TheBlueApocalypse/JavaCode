import java.io.*;
import java.util.*;
class Buses extends Vehicle {
	//unique method get# of seats and type of bus( tour, school
	//set all unique values
	//get all generic values
	//create a constructor for no values and all values assigned
	// create getters and setters for the unique values
	//create a to string method
	private int numOfSeats; 
	private String busType;
	private String[] acceptedValues = new String[9];
	
	// overloaded constructor
	public Buses(double inPrice, int inSpeed, String inTagLine, int numberOfSeats, String typeOfBus){ 
		super(inPrice, inSpeed, inTagLine);
		numOfSeats = numberOfSeats;
		this.setAcceptedValues();
		Scanner input = new Scanner(System.in);
		// can only be (tour, school, mini, or double-deckers)
		boolean quit = false;
		int x = 0;
		while(quit != true || x == 9){
			if(acceptedValues[x] == typeOfBus){
				quit = true;
			}
			x++;
		}
		if(quit == false){
			this.printAcceptedValues();
			System.out.println("Please enter a proper value");
			typeOfBus = input.nextString();
		}
		busType = typeOfBus;
		
	}
	//default constructor
	public Buses(){ 
		super();
		numOfSeats = 0;
		busType = "";
	}
	//gets num of seats
	public int getNumOfSeats(){
		return numOfSeats;
	}
	// gets bus type
	public String getBusType(){
		return busType;
	}
	//sets num of seats
	public void setNumOfSeats(int newNumOfSeats){
		numOfSeats = newNumOfSeats;
	}
	// sets bus type and checks for accepted value
	public void setBusType(String newBusType){
		Scanner input = new Scanner(System.in);
		// can only be (tour, school, mini, or double-deckers)
		boolean quit = false;
		int x = 0;
		//checks user value
		while(quit != true || x == 9){
			if(acceptedValues[x] == newBusType){
				quit = true;
			}
			x++;
		}
		//asks user for new value
		if(quit == false){
			this.printAcceptedValues();
			System.out.println("Please enter a proper value");
			newBusType = input.nextString();
		}
		busType = newBusType;
	}
	// stets the list so when the user enters the accepeted values 
	public void setAcceptedValues(){
		acceptedValues[0] = "Tour";
		acceptedValues[1] = "tour";
		acceptedValues[2] = "School";
		acceptedValues[3] = "school";
		acceptedValues[4] = "Mini";
		acceptedValues[5] = "mini";
		acceptedValues[6] = "Double Decker";
		acceptedValues[7] = "Double decker";
		acceptedValues[8] = "double decker";
	}
	//shows to the user the accepted types of buses
	public void printAcceptedValues(){
		System.out.println("These are the accepted values for bus type");
		for(int i = 0; i < 9; i++){
			System.out.println(acceptedValues[i]);
		}
	}
	public String toString(){ 
		return super.toString() + " " + numOfSeats + " " + busType; 
	}
}