class Trains extends Vehicle {
	//unique method get seating class, cost per meal
	//set all unique values
	//get all generic values
	//create a constructor for no values and all values assigned
	// create getters and setters for the unique values
	//create a to string method
}