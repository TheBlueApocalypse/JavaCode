class Vehicle {
	private double price; 
	private int speed; 
	private String tagLine;
	public Vehicle(double inPrice, int inSpeed, String inTagLine) 
	{ 
		price = inPrice; 
		speed = inSpeed; 
		tagLine = inTagLine;
	} 
	public Vehicle() 
	{ 
		price = 0.0; 
		speed = 0; 
		tagLine = "";
	}
	public double getPrice(){
		return price;
	}
	public int getSpeed(){
		return speed;
	}
	public String getTagLine(){
		return tagLine;
	}
	public void setPrice(double newPrice){
		price = newPrice;
	}
	public void setSpeed(int newSpeed){
		speed = newSpeed;
	}
	public void setTagLine(String newTagline){
		tagLine = newTagline;
	}
	public String toString() 
	{ 
		return price + " " + speed + " " + tagLine; 
	} 
}