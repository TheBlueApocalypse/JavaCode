
/*
Ariel Webster
Created: 9/18/18
For in class example and class lab, class 201

Fill in the methods below to create a functioning singly linked list
You should not change the provided method signatures, unless directed to by myself or the TA
*/

public class LinkedListStart {
	
	public Node head = null;

	public static void main(String [] args){
		
		//nodes to be added to the linkedlist
		Node p1 = new Node("Hugh");
		Node p2 = new Node("Taylor");
		Node p3 = new Node("Caleb");
		Node p4 = new Node("Justin");
		Node p5 = new Node("Drew");
		Node p6 = new Node("Christine");
		Node p7 = new Node("Will");
		Node p8 = new Node("Maggie");
		Node p9 = new Node("Rose");
		Node p10 = new Node("Hannah");
		Node p11 = new Node("Tamara");
		Node p12 = new Node("Jackie");
		Node p13 = new Node("Annette");
		
		LinkedListStart ll = new LinkedListStart();
		ll.push(p7);
		ll.push(p8);
		System.out.println(ll.peek());
		System.out.println(ll.pop());

		//System.out.println(ll.get(1).toString());
		
		
	}
	
	//adds an element to the head of the linked list
	public void push(Node p){
		if (head == null){
			head = p;
		}else{
			p.setNext(head);
			head.setPrev(p);
			head = p;
		}
	}
		
	//removes the element at the head of the linked list
	public Node pop(){
		Node temp = head;
		if(head != null)
			head = head.getNext();
		return temp;
	}
	
		public Node peek()
	{
		if(head == null)
		{
			throw new IllegalStateException("List is empty");
		}
		return head; //this throws an error
	}
}
