/************************************/
/*	Cameron Carpenter					*/
/*	Lab 1								*/
/*	Due 31 Jan 2020					*/
/*	COSC 201 - Prof. Webster			*/
/************************************/
// import java.io.*;
//import java.util.*;
class Untitled {
	public static void main(String[] args) {
		
	}
}