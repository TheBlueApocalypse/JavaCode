/************************************/
/*	Cameron Carpenter					*/
/*	Lab 0								*/
/*	Due 24 Jan 2020					*/
/*	COSC 201 - Prof. Webster			*/
/************************************/

import java.io.*;

import java.util.*;


class LabZero1 {

	static int fib(int x, int counter) {  
	
		if(x == 1)	
		{
		// base case
			System.out.println(counter+1);
			System.out.println(counter+2);
			return 1;
		// return print statments
		}
		else {	
			System.out.println(x+counter);
			counter+=2;
			return fib(x-1, counter);
			// return print statments
		}
	}
	
	static double arrayStats(double statsList[]) {
	
		Scanner input = new Scanner(System.in);
		double curr = 0;
		if(statsList[3] == statsList[4])
		{
			double mean = 0;
			mean = statsList[2]/statsList[3];
			System.out.println("The Mean is: " + mean);
			System.out.println("The Max is: " + statsList[0]);
			System.out.println("The Min is: " + statsList[1]);
			return 1;
		}
		else { 
			System.out.println("Input an integer"); 
			curr = input.nextInt();
			statsList[3]++;
			statsList[2]= statsList[2] + curr;
			if(curr > statsList[0]) {
				statsList[0] = curr;
			}
			if(curr<statsList[1]) {
				statsList[1] = curr;
			}
			return arrayStats(statsList);
		}		 	
	}
	
	static ArrayList readFile(Scanner textFile)
	{	
		ArrayList wordList = new ArrayList();
		String word = "";
		if(textFile.hasNext()){
			// after cheking th efile for next line it reads teh line then stores it
			word = textFile.next();
			wordList.add(word);
			System.out.println(wordList);	
			wordList.add(readFile(textFile));
			return wordList;
			//returning the list so the whole thing can be printed at the end
		}
		else{// base conditions
			System.out.println(wordList);
			return wordList;			
		}
	} 
	
	public static void main(String[] args)throws IOException , FileNotFoundException {
	
		int n;	
		Scanner input = new Scanner(System.in);
		// print Menu
		System.out.println("Lab 0 - System Menu:");
		System.out.println("Option 1: Prints values 0 to X"); 
		System.out.println("Option 2: Reads and print from a text file"); 
		System.out.println("Option 3: Finds Mean, Min, Max of an entered list of numbers"); 
		System.out.println("Option 4: Exits Program "); 
		System.out.println("");
		System.out.println("Input an integer for the menu option: "); 
			
		while ((n = input.nextInt()) != 4) {
			System.out.println("You entered option " + n);
			if (n == 1) // print values 0 to X
			{
				int x;
				int counter;
				System.out.println("Input an integer for the largest number: "); 
				x = input.nextInt();
				counter = x *-1;
				fib(x, counter); // call fib function
			}
			else if (n == 2){ // read and print text file
				File textFile = new File("Hello1.txt");
				
				// creates the file
				textFile.createNewFile();
				
				// creates a FileWriter Object
				FileWriter writerValue = new FileWriter(textFile); 
				
				// Writes the content to the file
				writerValue.write("This\n is\n an\n example\n"); 
				writerValue.flush();
				writerValue.close();
				//creates a list that will get the words from the file
				ArrayList wordList = new ArrayList();
				Scanner scan = new Scanner(textFile);
				wordList.add(readFile(scan));
				System.out.println(wordList);
			}
			else { // find mean, min, max of array
				System.out.println("How many nubers do you want to put into a list");
				double max = 0;
				double min = 0;
				double sum = 0;
				double count = 0;
				double length = input.nextDouble();
				double[] statsList = new double[5];
				System.out.println("Input an integer");
				double curr = input.nextDouble();
				max = curr;
				min = curr;
				sum = curr;
				count++;
				statsList[0]= max;
				statsList[1]= min;
				statsList[2]= sum;
				statsList[3]= count;
				statsList[4]= length;
				arrayStats(statsList); // call arrayStats function
			}
			System.out.println("Lab 0 - System Menu:");
			System.out.println("Option 1: Prints values 0 to X"); 
			System.out.println("Option 2: Reads and print from a text file"); 
			System.out.println("Option 3: Finds Mean, Min, Max of an entered list of numbers"); 
			System.out.println("Option 4: Exits Program "); 
			System.out.println("");
			System.out.println("Input an integer for the menu option: ");
		}
	}
}