import java.io.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.*;

class readFile {

	public static void main(String[] args) throws IOException , FileNotFoundException {
		File file = new File("Hello1.txt");
		
		// creates the file
		file.createNewFile();
		
		// creates a FileWriter Object
		FileWriter writer = new FileWriter(file); 
		
		// Writes the content to the file
		writer.write("This\n is\n an\n example\n"); 
		writer.flush();
		writer.close();
		//creates a list that will get the words from the file
		ArrayList wordList = new ArrayList();
		Scanner scan = new Scanner(file);
		wordList.add(readFile(scan));
		System.out.println(wordList);
	}
	static ArrayList readFile(Scanner theFile)
	{	
		ArrayList wordList = new ArrayList();
		String word = "";
		if(theFile.hasNext()){
			// after cheking th efile for next line it reads teh line then stores it
			word = theFile.next();
			wordList.add(word);
			System.out.println(wordList);	
			wordList.add(readFile(theFile));
			return wordList;
			//returning the list so the whole thing can be printed at the end
		}
		else{// base conditions
			System.out.println(wordList);
			return wordList;			
		}
	} 
}
