/************************************/
/*	Cameron Carpenter				*/
/*	Lab 1							*/
/*	Due 31 Jan 2020					*/
/*	COSC 201 - Prof. Webster		*/
/************************************/
import java.io.*;
import java.util.*;
import javax.naming.ldap.*;

class BigOLab {
	public static void main(String[] args)throws IOException , FileNotFoundException {
		int n;	
		Scanner input = new Scanner(System.in);
		// print Menu
		int fileChoice = 0;
		System.out.println("Lab 0 - System Menu:");
		System.out.println("Option 1: File Number 1"); 
		System.out.println("Option 2: File Number 2"); 
		System.out.println("Input an integer for the file option: "); 
		fileChoice = input.nextInt();
		System.out.println("Lab 0 - System Menu:");
		System.out.println("Option 1: run time of O(n)"); 
		System.out.println("Option 2: run time of O(n Log n)"); 
		System.out.println("Option 3: Exits Program "); 
		System.out.println("");
		System.out.println("Input an integer for the menu option: "); 
		int lineNum = 0;
		
		while ((n = input.nextInt()) != 3) {
			if (n == 1) // print values 0 to X
			{
				String num = "";
				int maxValue = 201;
				ArrayList<Integer> numList = new ArrayList<Integer>();
				System.out.println("You entered option " + n);
				if (fileChoice == 1) // Checks for file choice
				{
					File textFile = new File("PlausibleSum.txt");
				}
				else{
					File textFile = new File("noSumFile.txt");
				}
				
				//creates a list that will get the words from the file
				Scanner scan = new Scanner(textFile);
				while(scan.hasNext()) {
					// after cheking th efile for next line it reads the line then stores it
					num = scan.nextLine();
					lineNum = Integer.parseInt(num);
					System.out.println("lineNum integer is: " + lineNum);
					if(lineNum <= maxValue){
						System.out.println("lineNum is valid " + lineNum);
						numList.add(lineNum);
					}
				}
				System.out.println("The List is: ");
				System.out.println(numList);
				int numListProper[] = new int[numList.size()];
				int count = 0;
				while(count != numList.size()){
					numListProper[count] = numList.get(count);
					count++;
				}
				System.out.println("The List is: ");
				System.out.println(numList);
				// sorting algorithim
				//radix Sort
				radixSort(numListProper);
				count = 0;
				/*while(count != numListProper.length){
					System.out.println(numListProper[count]);
					count++;
				}*/ // checking the proper list print was achieved and the sort worked
				count = 0;
				int reverseCount = numListProper.length-1;
				int min = numListProper[count];
				int max = numListProper[reverseCount];
				int makes201 = 201 - numListProper[count];
				boolean sumEquals201 = false;
				if(max <= 101 && max >= 201 && min > 100){
					System.out.println(sumEquals201);
					System.out.println("fail");
				}
				else if(min <= 100 && min >= 0 && max < 101){
					System.out.println(sumEquals201);
					System.out.println("fail");
				}
				else{
					while(sumEquals201 == false){
						//checks to see if the sum is equal
						if(numListProper[count] + numListProper[reverseCount] == 201){
							sumEquals201 = true;
						}
					
						else{
							// decriments end value
							reverseCount--;
							if(numListProper[count] + numListProper[reverseCount] == 201){
								sumEquals201 = true;
							}
							//reinciments the values of reverse count so no value is missed in any possible file
							else if(numListProper[reverseCount] < makes201){
								reverseCount++;
								count++;
							}
						}
					}
				System.out.println(sumEquals201);
				}
				
			}
			else
			{
				System.out.println("You entered option " + n);

				String num = "";
				int maxValue = 201;
				ArrayList<Integer> numList = new ArrayList<Integer>();
				System.out.println("You entered option " + n);
				if (fileChoice == 1) // CHECKS FOR  FILE CHOICE
				{
					File textFile = new File("PlausibleSum.txt");
				}
				else{
					File textFile = new File("noSumFile.txt");
				}			
				//creates a list that will get the words from the file
				Scanner scan = new Scanner(textFile);
				while(scan.hasNext()) {
					// after cheking th efile for next line it reads the line then stores it
					num = scan.nextLine();
					lineNum = Integer.parseInt(num);
					System.out.println("lineNum integer is: " + lineNum);
					if(lineNum <= maxValue){
						System.out.println("lineNum is valid " + lineNum);
						numList.add(lineNum);
					}
				}
				System.out.println("The List is: ");
				System.out.println(numList);
				int numListProper[] = new int[numList.size()];
				int count = 0;
				while(count != numList.size()){
					numListProper[count] = numList.get(count);
					count++;
				}
				System.out.println("The List is: ");
				System.out.println(numList);
				// sorting algorithim
				//radix Sort
				heapSort(numListProper);
				count = 0;
				int reverseCount = numListProper.length-1;
				/*while(count != numListProper.length){
					System.out.println(numListProper[count]);
					count++;
				}*/ // checking the proper list print was achieved and the sort worked
				count = 0;
				int min = numListProper[count];
				int max = numListProper[reverseCount];
				int makes201 = 201 - numListProper[count];
				boolean sumEquals201 = false;
				if(max <= 101 && max >= 201 && min > 100){
					System.out.println(sumEquals201);
				}
				else if(min <= 100 && min >= 0 && max < 101){
					System.out.println(sumEquals201);
				}
				else{
					while(sumEquals201 == false){
						//checks to see if the sum is equal
						if(numListProper[count] + numListProper[reverseCount] == 201){
							sumEquals201 = true;
						}
						
						else{
							reverseCount--;
							if(numListProper[count] + numListProper[reverseCount] == 201){
								sumEquals201 = true;
							}

							//reinciments the values of reverse count so no value is missed in any possible file
							else if(numListProper[reverseCount] < makes201){							
								reverseCount++;
								count++;
							}
						}
					}
				System.out.println(sumEquals201);
				}
			}
		}
		
	}
	public static void buildheap(int []numList) {
		
	 /*
	  * As last non leaf node will be at (numList.length-1)/2 
	  * so we will start from this location for heapifying the elements
	  * */
	 for(int i=(numList.length-1)/2; i>=0; i--){
			  heapify(numList,i,numList.length-1);
		}
	}
 
	public static void heapify(int[] numList, int i,int size) { 
		int left = 2*i+1;
		int right = 2*i+2;
		int max;
		if(left <= size && numList[left] > numList[i]){
			max=left;
		} else {
			max=i;
		}
 
		if(right <= size && numList[right] > numList[max]) {
			max=right;
		}
		// If max is not current node, exchange it with max of left and right child
		if(max!=i) {
			exchange(numList,i, max);
			heapify(numList, max,size);
		}
	}
 
	public static void exchange(int[] numList,int i, int j) {
		  int t = numList[i];
		  numList[i] = numList[j];
		  numList[j] = t; 
	}
 
	public static int[] heapSort(int[] numList) {
	  
		buildheap(numList);
		int sizeOfHeap=numList.length-1;
		for(int i=sizeOfHeap; i>0; i--) {
			exchange(numList,0, i);
			sizeOfHeap=sizeOfHeap-1;
			heapify(numList, 0,sizeOfHeap);
		}
		return numList;
	}
	public static void radixSort(int[] numList) {
		final int RADIX = 10;
			
		// declare and initialize radList[]
		List<Integer>[] radList = new ArrayList[RADIX];
		
		for (int i = 0; i < radList.length; i++) {
			radList[i] = new ArrayList<Integer>();
		}

			// sort
		boolean maxLeng = false;
		int temp = -1, place = 1;
		while (!maxLeng) {
			maxLeng = true;
			
				// split numList between lists
			for (Integer i : numList) {
				temp = i / place;
				radList[temp % RADIX].add(i);
				if (maxLeng && temp > 0) {
					maxLeng = false;
				}
			}
				
			// empty lists into numList array
			int a = 0;
			for (int b = 0; b < RADIX; b++) {
				for (Integer i : radList[b]) {
					numList[a++] = i;
				}
				radList[b].clear();
			}
				
				// move to next digit
				place *= RADIX;
		}
	}
	// tried method based storage but logic was already built in main
	/*static int dataConvert(int){
		if (n == 1) // print values 0 to X
		{
			String num = "";
			int maxValue = 201;
			ArrayList numList = new ArrayList();
			System.out.println("You entered option " + n);
			File textFile = new File("PlausibleSum.txt");
			
			//creates a list that will get the words from the file
			Scanner scan = new Scanner(textFile);
			while(scan.hasNext()) {
				// after cheking th efile for next line it reads the line then stores it
				num = scan.nextLine();
				lineNum = Integer.parseInt(num);
				System.out.println("lineNum integer is: " + lineNum);
				if(lineNum <= maxValue){
					System.out.println("lineNum is valid " + lineNum);
					numList.add(lineNum);
				}
			int numListProper[] = new int[numList.size()];
			int count = 0;
			while(count != numList.size()){
				
			}
				numListProper[count] = numList.get(count);
				
			}
			System.out.println("The List is: ");
			System.out.println(numList);
		}
		else{
			String num = "";
			int maxValue = 201;
			ArrayList numList = new ArrayList();
			System.out.println("You entered option " + n);
			File textFile = new File("noSumFile.txt");
			
			//creates a list that will get the words from the file
			Scanner scan = new Scanner(textFile);
			while(scan.hasNext()) {
				// after cheking th efile for next line it reads the line then stores it
				num = scan.nextLine();
				lineNum = Integer.parseInt(num);
				System.out.println("lineNum integer is: " + lineNum);
				if(lineNum <= maxValue){
					System.out.println("lineNum is valid " + lineNum);
					numList.add(lineNum);
				}
			int numListProper[] = new int[numList.size()];
			int count = 0;
			while(count != numList.size()){
				
			}
				numListProper[count] = numList.get(count);
				
			}
			System.out.println("The List is: ");
			System.out.println(numList);
			return
		}
	}*/
}