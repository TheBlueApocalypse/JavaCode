package Lab5;

import java.util.Scanner;

public class Balanced {
	Node head;
	char[] desiredChars = {'(',')','{','}','[',']'};
	public Balanced() {
	}
	
	
	private boolean isParen(char c) {
		
		for(int i = 0;i < desiredChars.length;i++) {
			if(desiredChars[i] == c) {
				return true;
			}
		}
		return false;
	}
	
	public void loadString(String str) {
		head = null;
		char[] process = str.toCharArray();
		for(int i = 0;i < process.length;i++) {
			if(isParen(process[i])) {
				push(new Node(process[i]));
			}
		}
	}
	
	public boolean evaluateStack() {
		int leftParenC = 0;
		int rightParenC = 0;
		int leftBrakC = 0;
		int rightBrakC = 0;
		int leftBraceC = 0;
		int rightBraceC = 0;
		Boolean paren = false;
		Boolean brak = false;
		Boolean brace = false;
		while(peek()!= null){
			switch(peek()) {
				case "(":
				leftParenC++;
				pop();
				
				// code block
					break;
				case ")":
				rightParenC++;
				pop();
				// code block
					break;
				case "[":
				leftBrakC++;
				pop();
				// code block
					break;
				case "]":
				rightBrakC++;
				pop();
				// code block
					break;
				case "{":
				rightBrakC++;
				pop();
				// code block
					break;
				case "}":
				rightBrakC++;
				pop();
				// code block
					break;
				default:
				System.out.println("Hi");
			}
		}
		if(leftParenC == rightParenC){
			paren = true;
		}
		if(leftBrakC == rightBrakC){
			brak = true;
		}
		if(leftBraceC == rightBraceC){
			brace = true;
		}
		if(paren == true && brak == true && brace == true){
			System.out.println("Sytem is balanced");
		}
		else{
			System.out.println("Sytem is not balanced");
		}
	}
	
	//adds an element to the head of the linked list
		public void push(Node p){
			if (head == null){
				head = p;
			}else{
				p.setNext(head);
				head.setPrev(p);
				head = p;
			}
		}
			
		//removes the element at the head of the linked list
		public Node pop(){
			Node temp = head;
			if(head != null)
				head = head.getNext();
			return temp;
		}
		
		public Node peek()
		{
			if(head == null)
			{
				throw new IllegalStateException("List is empty");
			}
			return head; //this throws an error
		}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		Balanced b = new Balanced();
		System.out.println("Give me a string:");
		String input = scan.next();
		b.loadString(input);
		
		if(b.evaluateStack()) {
			System.out.println("This is a balanced string.");
		} else {
			System.out.println("This is an unbalanced string!");
		}
	}
}