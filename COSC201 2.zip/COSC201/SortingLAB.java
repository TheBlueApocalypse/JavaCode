import java.io.*;

import java.util.*;

class SortingLAB {
	public static void main(String[] args) {
		// this is the main function where you chose what will happen
		//big o is O(n^2)
		int firstNum = 0;
		// menu output
		System.out.println("Welcome to the sorting menu");
		System.out.println("Please enter a number between 1 - 3 for our menu options");
		System.out.println("1: Flip sort method");
		System.out.println("2: Quit the Program");
		//loop runs through the perosns choices from the menu
		Scanner input = new Scanner(System.in);
		while ((firstNum = input.nextInt()) != 3) {
			if (firstNum == 1) // does flip sort method
			{
				
				int[] list = new int [10];
				list[0] = 95;
				list[1] = 21;
				list[2] = 56;
				list[3] = 47;
				list[4] = 13;
				list[5] = 2;
				list[6] = 78;
				list[7] = 64;
				list[8] = 30;
				list[9] = 89;
				int counter = 0;
				int minPos = 0;
				int firstValue = 0;
				int firstSawp = 0;
				int secValue = 0;
				int secSawp = 0;
				int sizeLeft = 0;
				int loopCounter = 0;
				int decCount = 0;
				boolean sorted = false;
				// loop checks to see if the list of numbers is sorted
				while(sorted == false)
				{
					// loop runs though the lenght of the list
					while(counter != list.length-1)
					{
						// the values between the start and 5- the length are the vaules the flip can run through without causing an out of bounds

						// checks for the min value from first value
						if(list[counter] > list[counter+1])
						{
							minPos = counter+1;
						}
						// if not keep current as min
						else
						{
							minPos = counter;
						}
						// runs through the rest of the flip length
						for(int i = 2; i < list.length - counter-2; i++)
						{
							if(list[minPos] > list[counter+i])
							{
								minPos = counter+i;
								//System.out.println("1");
							}
						}
						// if min value is found swap the places of the mins
						if(list[counter] > list[minPos])
						{
							firstValue = list[counter];
							list[counter] = list[minPos];
							list[minPos] = firstValue;
							decCount = minPos - 1;
							for(int x = counter+1; x <= decCount;x++)
							{
								secValue = list[x];
								secSawp = list[decCount];
								list[decCount] = secValue;
								list[x] = secSawp;
								decCount--;
								//System.out.println("2");
							}
							//System.out.println("7");
							
						}
							
							
							// if min value is found swap the places of the mins
							
						counter++;
					}
						// the values that are after the set length of the flip to not cause out of bounds error
						
					boolean quit = false;
					int i = 0;
					// checks to see if list is sorted and weather it should stop the main loop or not
					while(quit == false)
					{
						//System.out.println("3");
						// checks initalil values this is necisary for the code 
						if(list[i] <= list[i+1] && i+1 < list.length-1)
						{
							sorted = true;
						}
						// checks final value for a sorted list and if true then says the list is sorted
						else if (list[i] <= list[i+1] && i+1 == list.length-1)
						{
							sorted = true;
							quit = true;
						}
						// checks final value for a sorted list and if False then says the list isn't sorted
						else if (list[i] > list[i+1] && i+1 == list.length-1)
						{
							sorted = false;
							quit = true;
						}
						// if any value isn't sorted then it fails and runs the sort algorithim again.
						else
						{
							sorted = false;
							quit = true;
						}
						i++;
					}
					

					counter = 0;
					loopCounter++;
					for(int x = 0; x < 10; x++)
					{
						System.out.println(list[x]);
					}
					if(loopCounter == 10)
					{
						sorted = true;
					}
					System.out.println(sorted);
				}
				// when sorted prints the list to prove its sorted
				
			}
			//for your end of the program

		}
	}
}